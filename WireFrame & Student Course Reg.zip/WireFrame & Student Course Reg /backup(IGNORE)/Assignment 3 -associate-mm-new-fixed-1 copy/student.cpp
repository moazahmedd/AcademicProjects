//
// Created by nouman on 12/2/2020.
//

#include "student.h"
#include "registration.h"

Student::Student() {
  studentId = 0;
  name = "";
  address = "";
  size = 5;
  countReg = 0;
  registrationList = new Registration *[size];
  init();
}
Student::Student(int sId, string n, string a) {
  studentId = sId;
  name = n;
  address = a;
  size = 5;
  countReg = 0;
  registrationList = new Registration *[size];
  init();
}
void Student::init() {
  for (int i = 0; i < size; ++i) {
    registrationList[i] = new Registration();
  }
}
void Student::setRegistration(Registration r){
    if(countReg < size) {
        registrationList[countReg]->setRegistrationId(r.getRegistrationId());
        registrationList[countReg]->setCourse(r.getCourse());
        registrationList[countReg]->setDescription(r.getDescription());
        registrationList[countReg]->setSemester(r.getSemester());
        registrationList[countReg]->setStudent(r.getStudent());
        countReg++;
    }
    else
        cout<<"Registration Already Full for this student"<<endl;
}
void Student::display() {
  cout << "Student Id: " << studentId << "\nName: " << name << "\nAddress: " << address <<endl;
    displayRegistration();
  cout<<endl;
}
void Student::displayRegistration(){
    for (int i = 0; i < countReg; ++i) {
        registrationList[i]->display();
    }
}
Registration Student::getRegistration(int index){
    return *registrationList[index];
}
int Student::getStudentId() const { return studentId; }

void Student::setStudentId(int studentId) { this->studentId = studentId; }

const string &Student::getName() const { return name; }

void Student::setName(const string &name) { this->name = name; }

const string &Student::getAddress() const { return address; }

void Student::setAddress(const string &address) { this->address = address; }

Registration **Student::getRegistrationList() const { return registrationList; }

void Student::setRegistrationList(Registration **registrationList) {
  Student::registrationList = registrationList;
}

int Student::getSize() const { return size; }

void Student::setSize(int size) { this->size = size; }

int Student::getCountReg() const {
    return countReg;
}

