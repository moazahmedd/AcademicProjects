#include <iostream>
#include "student.h"
#include "course.h"
#include "registration.h"

int main() {

   string namecourses[4] = {"Intro to Programming",
                            "Object Oriented Programming",
                            "Data Structures & Algo",
                            "Algorithm Design & Analysis"};

    Course *c101 = new Course(101,namecourses[0],4,namecourses[0]);
    Course *c201 = new Course(201,namecourses[1],4,namecourses[1]);
    Course *c301 = new Course(301,namecourses[2],4,namecourses[2]);
    Course *c401 = new Course(401,namecourses[3],4,namecourses[3]);
    Course *courseArray[4]= {c101,c201,c301,c401};

    Student *s100 = new Student(100,"Ahmad","Lahore");
    Student *s101 = new Student(101,"Ali","Lahore");
    Student *s102 = new Student(102,"Shahid","Lahore");
    Student *s103 = new Student(103,"Zahid","Lahore");
    Student *studentArray[4]={s100,s101,s102,s103};

    Registration *r100101 = new Registration(100101,"1",namecourses[0],c101,s100);
    Registration *r100201 = new Registration(100201,"1",namecourses[1],c201,s100);
    Registration *r101301 = new Registration(101301,"3",namecourses[2],c301,s101);
    Registration *r101401 = new Registration(101401,"3",namecourses[3],c401,s101);
    Registration *r102401 = new Registration(102401,"3",namecourses[3],c401,s102);
    Registration *r102101 = new Registration(102101,"3",namecourses[0],c101,s102);
    Registration *r103101 = new Registration(103101,"3",namecourses[0],c101,s103);
    Registration *registrationArray[7]= {r100101,r100201,r101301,r101401,r102401,r102101,r103101};

    s100->setRegistration(*r100101);
    c101->setRegistration(*r100101);

    s100->setRegistration(*r100201);
    c201->setRegistration(*r100201);

    s101->setRegistration(*r101301);
    c301->setRegistration(*r101301);

    s101->setRegistration(*r101401);
    c401->setRegistration(*r101401);

    s102->setRegistration(*r102101);
    c101->setRegistration(*r102101);

    s102->setRegistration(*r102401);
    c401->setRegistration(*r102401);

    s103->setRegistration(*r103101);
    c101->setRegistration(*r103101);


    int personType;
    cout<<"  **  Welcome to Course Student Registration System  **  "<<endl;
    cout<<"Who are you? \n1. Student \n2. Courses \n3. Registration \nInput number: ";
    cin>>personType;
    while(personType<1 || personType>3){
        cout<<"Invalid Input.. please re-input number: ";
        cin>>personType;
    }
    cout<<endl;

        //STUDENT MENU.
    if (personType==1){
        //int studentMenuOption;
        s101->getStudentId();
        cout<<" \t\t** STUDENT MENU **"<<endl<<endl;
        cout<<"-----------------"<<endl;
        cout<<"|| Student IDs ||"<<endl;
        cout<<"-----------------"<<endl;
        for (int i = 0; i < 4; ++i) {
            cout<<"\t"<<studentArray[i]->getStudentId()<<endl;
        }
    cout<<endl;
    int StdId;
    cout<<"Input student ID: ";
    cin>>StdId;
        int found=0;
        for (int i = 0; i < 4; ++i) {
            if (StdId == studentArray[i]->getStudentId()){
                studentArray[i]->display();     //NOT WORKING - NOT GIVING REGISTRATION DETAILS IDK WHY.
                found=1;
            }
        }
        if (found==0){
            cout<<"Student ID not found!"<<endl;
        }
    }

    else if (personType==2){
        cout<<" ** Instructor Menu **"<<endl;
        cout<<"----------------"<<endl;
        cout<<"|| Course IDs ||"<<endl;
        cout<<"----------------"<<endl;
        for (int i = 0; i < 4; ++i) {
            cout<<"   \t" <<courseArray[i]->getCourseId()<<endl;
        }
        int CourseId;
        cout<<"Input Course ID: ";
        cin>>CourseId;
        int found=0;
        for (int i = 0; i < 4; ++i) {
            if (CourseId == courseArray[i]->getCourseId()){
                courseArray[i]->display();
                found=1;
            }
        }
        if (found==0){
            cout<<"Course ID not found!"<<endl;
        }
    }

    else if(personType==3){
        int regId;
        cout<<" ** Registration (Administrator) Menu **"<<endl;
        cout<<"----------------------"<<endl;
        cout<<"|| Registration IDs ||"<<endl;
        cout<<"----------------------"<<endl;

        for (int i = 0; i < 7; ++i) {
            cout<<"   \t"<<registrationArray[i]->getRegistrationId()<<endl;
        }

        cout<<"Input Registration ID: ";
        cin>>regId;

        int found=0;
        for (int i = 0; i < 7; ++i) {
            if(regId == registrationArray[i]->getRegistrationId()){
                registrationArray[i]->display();
                found=1;
            }
        }
        if(found==0){
            cout<<"Registration ID not found!"<<endl;
        }
    }

    return 0;
}

/**





    r100101->display();
    cout<<endl<<endl;
    r100201->display();
    cout<<endl<<endl;
    s100->display();
    cout<<endl<<endl;

    r101301->display();
    cout<<endl<<endl;
    r101401->display();
    cout<<endl<<endl;
    s101->display();
    cout<<endl<<endl;

    r100101->display();

c101->setRegistration(*r100101);
c201->setRegistration(*r100201);
c301->setRegistration(*r101301);
c401->setRegistration(*r101401);

c101->display();
c201->display();
c301->display();
c401->display();


 *
 */
