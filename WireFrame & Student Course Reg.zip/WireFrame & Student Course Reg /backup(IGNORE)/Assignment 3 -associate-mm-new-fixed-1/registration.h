//
// Created by nouman on 12/2/2020.
//

#ifndef ASSOCIATE_MM_NEW_REGISTRATION_H
#define ASSOCIATE_MM_NEW_REGISTRATION_H

#include <iostream>

#include<string.h>
#include "course.h"
//#include "course.h"
#include "student.h"

using namespace std;


class Registration{
public:
    Registration();
    Registration(int rId,string sem,string de,Course *c,Student *s);
    Registration(int rId,string sem,string de,Course c,Student* s);
    Registration(int rId,string sem,string de);


    int getRegistrationId() const ;

    void setRegistrationId(int registrationId) ;

    const string &getSemester() const ;

    void setSemester(const string &semester) ;

    const string &getDescription() const ;

    void setDescription(const string &description);

    Student *getStudent() const ;

    void setStudent(Student *student) ;

    Course *getCourse() const ;

    void setCourse(Course *course);

    void  display();

private:
    int registrationId;
    string semester;
    string description;

    //for association.
    Student *student;
    Course *course;
};
#endif //ASSOCIATE_MM_NEW_REGISTRATION_H
