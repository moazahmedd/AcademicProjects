//
// Created by nouman on 12/2/2020.
//

#ifndef ASSOCIATE_MM_NEW_COURSE_H
#define ASSOCIATE_MM_NEW_COURSE_H
#include <iostream>
#include<string.h>
class Registration;

using namespace std;

class Course{
public:
    Course() ;

    Course(int courseId, string title, int credithours, const string &description) ;

    int getCourseId();

    void setCourseId(int courseId) ;

    string getTitle() ;

    void setTitle(string title) ;

    int getCredithours() ;

    void setCredithours(int credithours) ;

    string getDescription() ;

    void setDescription(string description) ;

    void display() ;
    Registration **getRegistrationList() ;

    void setRegistrationList(Registration **registrationList) ;
    int getSize();
    void init();
    void setSize(int size) ;
    void displayRegistration();
    Registration getRegistration(int index);
    void setRegistration(Registration r);


private:
    int courseId;
    string title;
    int credithours;
    string description;

    // these are for association
    Registration **registrationList;
    int size;
    int countReg;

};


#endif //ASSOCIATE_MM_NEW_COURSE_H
