//
// Created by nouman on 12/2/2020.
//

#ifndef ASSOCIATE_MM_NEW_STUDENT_H
#define ASSOCIATE_MM_NEW_STUDENT_H
#include <iostream>
#include<string.h>
using namespace std;

class Registration;

class Student{
public:
    Student();

    Student(int sId, string n, string a);

    void init();

    void  display();

    int getStudentId() const ;

    void setStudentId(int studentId) ;

    const string &getName() const ;

    void setName(const string &name) ;

    const string &getAddress() const;

    void setAddress(const string &address);

    void setRegistration(Registration r);

    Registration getRegistration(int index);

    Registration **getRegistrationList() const ;

    void displayRegistration();

   void setRegistrationList(Registration **registrationList) ;
    int getSize() const ;

    void setSize(int size) ;

    int getCountReg() const;

    private:
    int studentId;
    string name;
    string address;

    //for association
    Registration **registrationList;
    int size;
    int countReg;
};
#endif //ASSOCIATE_MM_NEW_STUDENT_H
