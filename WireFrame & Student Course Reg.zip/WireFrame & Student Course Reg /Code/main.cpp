#include <iostream>
#include "student.h"
#include "course.h"
#include "registration.h"
int main() {

   string namecourses[4] = {"Intro to Programming",
                            "Object Oriented Programming",
                            "Data Structures & Algo",
                            "Algorithm Design & Analysis"};
    int courseCount=4;
    Course *c101 = new Course(101,namecourses[0],4,namecourses[0]);
    Course *c201 = new Course(201,namecourses[1],4,namecourses[1]);
    Course *c301 = new Course(301,namecourses[2],4,namecourses[2]);
    Course *c401 = new Course(401,namecourses[3],4,namecourses[3]);
    Course *courseArray[]= {c101,c201,c301,c401};

    int studentCount=4;
    Student *s100 = new Student(100,"Ahmad","Lahore");
    Student *s101 = new Student(101,"Ali","Lahore");
    Student *s102 = new Student(102,"Shahid","Lahore");
    Student *s103 = new Student(103,"Zahid","Lahore");
    Student *studentArray[]={s100,s101,s102,s103};

    int registrationCount=7;
    Registration *r100101 = new Registration(100101,"1",namecourses[0],c101,s100);
    Registration *r100201 = new Registration(100201,"1",namecourses[1],c201,s100);
    Registration *r101301 = new Registration(101301,"3",namecourses[2],c301,s101);
    Registration *r101401 = new Registration(101401,"3",namecourses[3],c401,s101);
    Registration *r102401 = new Registration(102401,"3",namecourses[3],c401,s102);
    Registration *r102101 = new Registration(102101,"3",namecourses[0],c101,s102);
    Registration *r103101 = new Registration(103101,"3",namecourses[0],c101,s103);
    Registration *registrationArray[]= {r100101,r100201,r101301,r101401,r102401,r102101,r103101};

    s100->setRegistration(*r100101);
    c101->setRegistration(*r100101);

    s100->setRegistration(*r100201);
    c201->setRegistration(*r100201);

    s101->setRegistration(*r101301);
    c301->setRegistration(*r101301);

    s101->setRegistration(*r101401);
    c401->setRegistration(*r101401);

    s102->setRegistration(*r102101);
    c101->setRegistration(*r102101);

    s102->setRegistration(*r102401);
    c401->setRegistration(*r102401);

    s103->setRegistration(*r103101);
    c101->setRegistration(*r103101);


    int personType;
    cout<<"  **  Welcome to Course Student Registration System  **  "<<endl;
    cout<<"Who are you? \n1. Student \n2. Instructor \n3. Registrar \nInput number: ";
    cin>>personType;
    while(personType<1 || personType>3){
        cout<<"Invalid Input.. please re-input number: ";
        cin>>personType;
    }
    cout<<endl;

    //STUDENT MENU.

    if (personType==1){
        cout<<" \t\t** STUDENT MENU **"<<endl;
        cout<<" \t\t-----------------"<<endl;
        cout<<" \t\t|| Student IDs ||"<<endl;
        cout<<" \t\t-----------------"<<endl;
        for (int i = 0; i < studentCount; ++i) {
            cout<<" \t\t|\t   "<<studentArray[i]->getStudentId()<<"\t\t|"<<endl;
        }
        cout<<" \t\t-----------------"<<endl;
        int toDo;
        cout<<"\nWhat would u like to do? \n1. View your courses \n2. Enroll in a course \n3. Withdraw from a course \nInput number for option u would like to perform: ";
        cin>> toDo;
        cout<<endl;
        int StdId;

        if(toDo == 1){
            cout<<"Input student ID: ";
            cin>>StdId;
            int found=0;
            for (int i = 0; i < studentCount; ++i) {
                if (StdId == studentArray[i]->getStudentId()){
                    studentArray[i]->display();
                    found=1;
                }
            }
            if (found==0){
                cout<<"Student ID not found!"<<endl;
            }
        }
        else if(toDo == 2){
            Registration *newVal;
            int CourseId;
            string sem;
            cout<<"Input student ID: ";
            cin>>StdId;
            cout<<"Your current registered courses are as follows: "<<endl;
            for (int i = 0; i < studentCount; ++i) {
                if (StdId == studentArray[i]->getStudentId()){
                    studentArray[i]->display();
                }
            }
            cout<<"-----------------"<<endl;
            cout<<"||  Course IDs ||"<<endl;
            cout<<"-----------------"<<endl;
            for (int i = 0; i < courseCount; ++i) {
                cout<<"|\t   "<<courseArray[i]->getCourseId()<<"\t\t|"<<endl;
            }
            cout<<"-----------------"<<endl;
            cout<<"Input Course ID you want to enroll in: ";
            cin>>CourseId;
            string de;
            switch (CourseId) {
                case 101: de = namecourses[0]; break;
                case 201: de = namecourses[1]; break;
                case 301: de = namecourses[2]; break;
                case 401: de = namecourses[3]; break;
            }
            string rid = to_string(StdId) + to_string(CourseId);
            int rId = stoi(rid); //string to INT function.
            int success=0; //flag to check new course registration successful or not
            int check=0; //flag to check if course already registered or not.
            for (int i = 0; i < courseCount; ++i) {
                for (int j = 0; j < studentCount; ++j) {
                    if (CourseId==courseArray[i]->getCourseId() && StdId==studentArray[j]->getStudentId()){
                        for (int k = 0; k < registrationCount; ++k) {
                            if (registrationArray[k]->getRegistrationId()==rId && check==0){
                                cout<<"Already registered course!\n";
                                check=1;
                            }
                        }
                        if (check!=1){
                            cout<<"Input Semester: ";
                            cin>>sem;
                            cout<<"New Registration successful!\n";
                            newVal = new Registration(rId,sem,de,courseArray[i],studentArray[j]);
                            newVal->display();
                            success=1;
                        }
                    }
                }
            }
        if (success==1){
            for (int k = 0; k < studentCount; ++k) {
                if (StdId==studentArray[k]->getStudentId()){
                    studentArray[k]->setRegistration(*newVal);
                }
            }
            for (int l = 0;  l < courseCount ; ++l) {
                if (CourseId == courseArray[l]->getCourseId()) {
                    courseArray[l]->setRegistration(*newVal);
                }
            }
            cout << "\nYour updated courses are as follows:- "<<endl;
            for (int i = 0; i < studentCount; ++i) {
                if (StdId == studentArray[i]->getStudentId()) {
                        studentArray[i]->display();
                }
            }
        }
    }
        else if (toDo == 3) {
            int CourseId;
            cout << "Input student ID: ";
            cin >> StdId;
            cout << "Your current registered courses are as follows: " << endl;
            for (int i = 0; i < studentCount; ++i) {
                if (StdId == studentArray[i]->getStudentId()) {
                    studentArray[i]->display();
                }
            }
            cout << "-----------------" << endl;
            cout << "||  Course IDs ||" << endl;
            cout << "-----------------" << endl;
            for (int i = 0; i < courseCount; ++i) {
                cout << "|\t   " << courseArray[i]->getCourseId() << "\t\t|" << endl;
            }
            cout << "-----------------" << endl;
            cout << "Input Course ID you want to withdraw from: ";
            cin >> CourseId;
            string rid = to_string(StdId) + to_string(CourseId);
            int rId = stoi(rid);   //string to INT function.
            Registration *newRegistrationArray[7]={nullptr,nullptr,nullptr,nullptr,nullptr,nullptr,nullptr};
            int newCount = 0;
            for (int i = 0; i < registrationCount; ++i) {
                if (rId != registrationArray[i]->getRegistrationId()) {
                    newRegistrationArray[i] = registrationArray[i];
                    //newRegistrationArray[i]->display();
                    newCount += 1;
                }
                else{
                    newRegistrationArray[i]= nullptr;
                }
            }

            int withdraw=0;
            for(int i=0; i<registrationCount; i++)      //For this loop, help taken from basic code to create my own. https://codescracker.com/cpp/program/cpp-program-delete-element-from-array.htm
            {
                if(newRegistrationArray[i]== nullptr)
                {
                    withdraw=1;
                    for(int j=i; j<(registrationCount-1); j++)
                        newRegistrationArray[j] = newRegistrationArray[j+1];
                    i--;
                    registrationCount--;
                }
            }
            if (withdraw==1){
                cout<<"Withdrawal has been successful! Courses for Student ID "<<StdId<<" are as follows:-"<<endl;
            }
            else{
                cout<<"Error! You were never registered in the course you chose to withdraw from."<<endl;
            }
            for (int i = 0; i < registrationCount; ++i) {
                registrationArray[i]=newRegistrationArray[i];
            }
            int enrolledTotal=0;
            for (int i = 0; i < registrationCount; ++i) {
                if (StdId == registrationArray[i]->getStudent()->getStudentId() && withdraw==1){
                    registrationArray[i]->display();
                    enrolledTotal+=1;
                }
            }
            if (withdraw==1)
            cout<<"Updated number of enrolled courses: "<<enrolledTotal<<endl;
        }
    }


    else if (personType==2){
        cout<<" ** Instructor Menu **"<<endl;
        cout<<"-----------------"<<endl;
        cout<<"||  Course IDs ||"<<endl;
        cout<<"-----------------"<<endl;
        for (int i = 0; i < courseCount; ++i) {
            cout<<"|\t   "<<courseArray[i]->getCourseId()<<"\t\t|"<<endl;
        }
        cout<<"-----------------"<<endl;

        int CourseId;
        cout<<"Input Course ID to view students registered in your course: ";
        cin>>CourseId;
        int found=0;
        for (int i = 0; i < courseCount; ++i) {
            if (CourseId == courseArray[i]->getCourseId()){
                courseArray[i]->display();
                found=1;
            }
        }
        if (found==0){
            cout<<"Course ID not found!"<<endl;
        }
    }

    else if(personType==3){
        int regId;
        cout<<" ** Registration (Administrator) Menu **"<<endl;
        cout<<"-----------------------------------------------------"<<endl;
        cout<<"|| Registration IDs ||  Course IDs ||  Student IDs ||"<<endl;
        cout<<"-----------------------------------------------------"<<endl;

        for (int i = 0; i < 7; ++i) {
            cout<<"| \t"<<registrationArray[i]->getRegistrationId();
            if (i<courseCount){
                cout<<"\t\t\t|   "<<courseArray[i]->getCourseId()<<"\t\t\t|";
            }
            else{
                cout<<"\t\t\t|\t\t\t\t|";
            }

            if (i<studentCount){
                cout<<"\t"<<studentArray[i]->getStudentId()<<"\t\t\t|"<<endl;
            }
            else{
                cout<<"\t\t\t\t|"<<endl;
            }
        }
        cout<<"-----------------------------------------------------"<<endl;
        int toDo;
        cout<<"\n1. View Registration ID details \n2. View Course ID details \n3. View Student ID details \n4. Enroll student in a course \n5. Withdraw student from a course \nInput option number: ";
        cin>>toDo;
        if (toDo==1){
            cout<<"\nInput Registration ID: ";
            cin>>regId;

            int found=0;
            for (int i = 0; i < registrationCount; ++i) {
                if(regId == registrationArray[i]->getRegistrationId()){
                    registrationArray[i]->display();
                    found=1;
                }
            }
            if(found==0){
                cout<<"Registration ID not found!"<<endl;
            }
        }
        else if (toDo==2){
            int CourseId;
            cout<<"Input Course ID to view students registered in your course: ";
            cin>>CourseId;
            int found=0;
            for (int i = 0; i < courseCount; ++i) {
                if (CourseId == courseArray[i]->getCourseId()){
                    courseArray[i]->display();
                    found=1;
                }
            }
            if (found==0){
                cout<<"Course ID not found!"<<endl;
            }
        }
        else if (toDo==3){
            int StdId;
                cout<<"Input student ID: ";
                cin>>StdId;
                int found=0;
                for (int i = 0; i < studentCount; ++i) {
                    if (StdId == studentArray[i]->getStudentId()){
                        studentArray[i]->display();
                        found=1;
                    }
                }
                if (found==0){
                    cout<<"Student ID not found!"<<endl;
                }
        }
        else if (toDo==4){
            int StdId;
            Registration *newVal;
            int CourseId;
            string sem;
            cout<<"Input student ID: ";
            cin>>StdId;
            cout<<"Your current registered courses are as follows: "<<endl;
            for (int i = 0; i < studentCount; ++i) {
                if (StdId == studentArray[i]->getStudentId()){
                    studentArray[i]->display();
                }
            }
            cout<<"-----------------"<<endl;
            cout<<"||  Course IDs ||"<<endl;
            cout<<"-----------------"<<endl;
            for (int i = 0; i < courseCount; ++i) {
                cout<<"|\t   "<<courseArray[i]->getCourseId()<<"\t\t|"<<endl;
            }
            cout<<"-----------------"<<endl;
            cout<<"Input Course ID: ";
            cin>>CourseId;
            string de;
            switch (CourseId) {
                case 101: de = namecourses[0]; break;
                case 201: de = namecourses[1]; break;
                case 301: de = namecourses[2]; break;
                case 401: de = namecourses[3]; break;
            }
            string rid = to_string(StdId) + to_string(CourseId);
            int rId = stoi(rid);   ///string to INT function.
            int success=0;
            int check=0;
            for (int i = 0; i < courseCount; ++i) {
                for (int j = 0; j < studentCount; ++j) {
                    if (CourseId==courseArray[i]->getCourseId() && StdId==studentArray[j]->getStudentId()){
                        for (int k = 0; k < registrationCount; ++k) {
                            if (registrationArray[k]->getRegistrationId()==rId && check==0){
                                cout<<"Already registered course!\n";
                                check=1;
                            }
                        }
                        if (check!=1){
                            cout<<"Input Semester: ";
                            cin>>sem;
                            cout<<"New Registration successful!\n";
                            newVal = new Registration(rId,sem,de,courseArray[i],studentArray[j]);
                            newVal->display();
                            success=1;
                        }
                    }
                }
            }
            if (success==1){
                for (int k = 0; k < studentCount; ++k) {
                    if (StdId==studentArray[k]->getStudentId()){
                        studentArray[k]->setRegistration(*newVal);
                    }
                }
                for (int l = 0;  l < courseCount ; ++l) {
                    if (CourseId == courseArray[l]->getCourseId()) {
                        courseArray[l]->setRegistration(*newVal);
                    }
                }
                cout << "\nYour updated courses are as follows:- "<<endl;
                for (int i = 0; i < studentCount; ++i) {
                    if (StdId == studentArray[i]->getStudentId()) {
                        studentArray[i]->display();
                    }
                }
            }
        }
        else if (toDo==5){
            int CourseId;
            int StdId;
            cout << "Input student ID: ";
            cin >> StdId;
            cout << "Your current registered courses are as follows: " << endl;
            for (int i = 0; i < studentCount; ++i) {
                if (StdId == studentArray[i]->getStudentId()) {
                    studentArray[i]->display();
                }
            }
            cout << "-----------------" << endl;
            cout << "||  Course IDs ||" << endl;
            cout << "-----------------" << endl;
            for (int i = 0; i < courseCount; ++i) {
                cout << "|\t   " << courseArray[i]->getCourseId() << "\t\t|" << endl;
            }
            cout << "-----------------" << endl;
            cout << "Input Course ID you want to withdraw from: ";
            cin >> CourseId;
            string rid = to_string(StdId) + to_string(CourseId);
            int rId = stoi(rid);   ///string to INT function.

            Registration *newRegistrationArray[7]={nullptr,nullptr,nullptr,nullptr,nullptr,nullptr,nullptr};
            int newCount = 0;
            for (int i = 0; i < registrationCount; ++i) {
                if (rId != registrationArray[i]->getRegistrationId()) {
                    newRegistrationArray[i] = registrationArray[i];
                    //newRegistrationArray[i]->display();
                    newCount += 1;
                }
                else{
                    newRegistrationArray[i]= nullptr;
                }
            }

            int withdraw=0;
            for(int i=0; i<registrationCount; i++)      //For this loop, help taken from basic code to create my own. https://codescracker.com/cpp/program/cpp-program-delete-element-from-array.htm
            {
                if(newRegistrationArray[i]== nullptr)
                {
                    withdraw=1;
                    for(int j=i; j<(registrationCount-1); j++)
                        newRegistrationArray[j] = newRegistrationArray[j+1];
                    i--;
                    registrationCount--;
                }
            }
            if (withdraw==1){
                cout<<"Withdrawal has been successful! Courses for Student ID "<<StdId<<" are as follows:-"<<endl;
            }
            else{
                cout<<"Error! You were never registered in the course you chose to withdraw from."<<endl;
            }
            for (int i = 0; i < registrationCount; ++i) {
                registrationArray[i]=newRegistrationArray[i];
            }
            int enrolledTotal=0;
            for (int i = 0; i < registrationCount; ++i) {
                if (StdId == registrationArray[i]->getStudent()->getStudentId() && withdraw==1){
                    registrationArray[i]->display();
                    enrolledTotal=1;
                }
            }
            if (withdraw==1)
                cout<<"Updated number of enrolled courses: "<<enrolledTotal<<endl;
            }
    }

    return 0;
}
