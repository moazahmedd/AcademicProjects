//https://atechdaily.com/posts/AVL-Tree-Implementation-in-Cplusplus
#include <iostream>
#include <ctime>
#include <iomanip>
#include <fstream>
#include<stdio.h>
using namespace std;

class Account {
public:
    Account() {
        AccID = 0;
        AccBalance = 0;
        recNum = 0;
        firstName = lastName = "";
    }
    Account(int id, string fname, string lname, double balance) {
        AccID = id;
        firstName = fname;
        lastName = lname;
        AccBalance = balance;
    }

    void display() {
        //cout<<"Record Num: "<<recNum<<endl;
        cout << "Account ID: " << AccID << endl;
        cout << "First Name: " << firstName << endl;
        cout << "Last Name: " << lastName << endl;
        cout << "Account Balance: " << AccBalance << endl;
    }

    int getAccId() const {
        return AccID;
    }

    void setAccId(int accId) {
        AccID = accId;
    }

    const string& getFirstName() const {
        return firstName;
    }

    void setFirstName(const string& firstName) {
        Account::firstName = firstName;
    }

    const string& getLastName() const {
        return lastName;
    }

    void setLastName(const string& lastName) {
        Account::lastName = lastName;
    }

    double getAccBalance() const {
        return AccBalance;
    }

    void setAccBalance(double Balance) {
        AccBalance = Balance;
    }

    int getKey() {
        return AccID;
    }

    long getRecNum() const {
        return recNum;
    }

    void setRecNum(long recNum) {
        Account::recNum = recNum;
    }

private:
    int AccID;
    string firstName;
    string lastName;
    double AccBalance;
    long recNum;
    friend class AVLTree;
};

// **************************************************
// Adelson-Velskii and Landis dynamically balanced
// tree class.
class AVLTree {

    // - - - - - - - - - - - - - - - - - - - - - - - -
    // Private Node subclass for the nodes of the tree.
private:
    class Node {

        // - - - - - - - - - - - - - - - - - - - - - -
        // Private data for the node of the tree.
    private:
        // The actual data being stored.
        Account data;
        // The height of this node from the deepest
        // point.
        int height;
        // A pointer to the left subtree.
        Node* left_child;
        // A pointer to the node's parent.
        Node* parent;
        // A pointer to the right subtree.
        Node* right_child;

        // - - - - - - - - - - - - - - - - - - - - - -
        // Public methods to process the node.
    public:
        // Constructor initializing the data.
        Node(Account acc); //CHANGES DONE - Moaz
        // Calculate the balance point.
        int getBalance();
        // Get the actual data
        Account getData(); //CHANGES DONE - Moaz
        Account* byPointerData();

        // Get the height.
        int getHeight();
        // Get the left subtree.
        Node* getLeftChild();
        // Get the node's parent.
        Node* getParent();
        // Get the right subtree.
        Node* getRightChild();
        // Remove the node's parent.
        void removeParent();
        // Set the left subtree.
        Node* setLeftChild(Node* newLeft);
        // Set the right subtree.
        Node* setRightChild(Node* newRight);
        // Set the node's height.
        int updateHeight();

    }; // Node

    // - - - - - - - - - - - - - - - - - - - - - - - -
    // Private data for the tree.
private:
    // A pointer to the top node of the tree.
    Node* root;
    int count;
    // - - - - - - - - - - - - - - - - - - - - - - - -
    // Private methods to process the tree.
private:
    // Balance the subtree.
    void balanceAtNode(Node* n);
    // Find the node containing the data.
    Node* findNode(int val); //Changes done - Moaz
    // Print the subtree.
    void printSubtree(Node* subtree, int depth,
                      int offset, bool first);
    // Rotate the subtree left.
    void rotateLeft(Node* n);
    // Rotate the subtree left.
    void rotateRight(Node* n);
    // Set the root.
    void setRoot(Node* n);
    // Figure out the default spacing for element.
    int spacing(int offset);
    void showHelper(Node* p, int level) const;
    void displayInOrder(Node*) const;
    Node* updateNode(int val); //Addition done - Moaz


    // - - - - - - - - - - - - - - - - - - - - - - - -
    // Public methods to process the tree.
public:
    // Constructor to create an empty tree.
    AVLTree(); //Made changes - Moaz.
    // Constructor to populate the tree with one node.
    AVLTree(Account val); //CHANGES DONE -Moaz
    // Get the tree's height.
    int getHeight();
    // Insert the value into the tree.
    bool insert(Account acc); //Changes done - Moaz
    // Print the tree.
    void print(); //Change done - Moaz
    // Remove the value from the tree.
    bool remove(Account acc); //Changes done - Moaz
    void showStructure() const; //Changes done - Moaz
    int getCount() { //Added - Moaz
        return count;
    }
    void displayInOrder() const //Added - Moaz
    {
        displayInOrder(root);
    }
    void find(int val) {
        Node* temp = findNode(val);
        if (temp)
            temp->getData().display();
        else
            cout << "Account not found!" << endl;
    }
    void update(int val) {
        Node* temp = updateNode(val); //Changes done - Moaz
        if (temp) {
            cout << " * Data Updated! *" << endl;
        }
        else {
            cout << "Sorry node not found!" << endl << endl;
        }
    }

}; // AVLTree

// **************************************************
// AVLTree's Node subclass methods.

// --------------------------------------------------
// Constructor initializing the data.
AVLTree::Node::Node(Account acc) {
    data = acc;
    height = 0;
    parent = nullptr;
    left_child = nullptr;
    right_child = nullptr;
} // Node

// --------------------------------------------------
// Calculate the balance point. Negative, when the
// right side is deeper. Zero, when both sides are
// the same. Positive, when the left side is deeper.
int AVLTree::Node::getBalance() {

    // If we don't have a left subtree, check the
    // right.
    int result;
    if (left_child == nullptr)

        // If neither subtree exists, return zero.
        if (right_child == nullptr)
            result = 0;

            // Otherwise, the right subtree exists so make
            // it's height negative and subtract one.
        else
            result = -right_child->height - 1;

        // Otherwise, we have a left subtree so if we
        // don't have a right one, return the left's
        // height plus one.
    else if (right_child == nullptr)
        result = left_child->height + 1;

        // Otherwise, both subtrees exist so subtract
        // them to return the difference.
    else
        result = left_child->height - right_child->height;
    return result;
} // getBalance

// --------------------------------------------------
// Get the actual data.
Account AVLTree::Node::getData() {
    return data;
} // getData

Account* AVLTree::Node::byPointerData() {
    return &data;
} // getData2



// --------------------------------------------------
// Get the height.
int AVLTree::Node::getHeight() {
    return height;
} // getHeight

// --------------------------------------------------
// Get the left subtree.
AVLTree::Node* AVLTree::Node::getLeftChild() {
    return left_child;
} // getLeftChild

// --------------------------------------------------
// Get the node's parent.
AVLTree::Node* AVLTree::Node::getParent() {
    return parent;
} // getParent

// --------------------------------------------------
// Get the right subtree.
AVLTree::Node* AVLTree::Node::getRightChild() {
    return right_child;
} // getRightChild

// --------------------------------------------------
// Remove the node's parent.
void AVLTree::Node::removeParent() {
    parent = nullptr;
} // removeParent

// --------------------------------------------------
// Set the left subtree.
AVLTree::Node* AVLTree::Node::setLeftChild(
        Node* newLeft) {

    // If there is a left node, set it's parent to
    // be us. In any event, make it our left subtree
    // and update the height.
    if (newLeft != nullptr)
        newLeft->parent = this;
    left_child = newLeft;
    updateHeight();
    return left_child;
} // setLeftChild

// --------------------------------------------------
// Set the right subtree.
AVLTree::Node* AVLTree::Node::setRightChild(
        Node* newRight) {

    // If there is a right node, set it's parent to
    // be us. In any event, make it our right subtree
    // and update the height.
    if (newRight != nullptr)
        newRight->parent = this;
    right_child = newRight;
    updateHeight();
    return right_child;
} // setRightChild

// --------------------------------------------------
// Set the node's height.
int AVLTree::Node::updateHeight() {

    // If we don't have a left subtree, check the
    // right.
    if (left_child == nullptr)

        // If we don't have either subtree, the height
        // is zero.
        if (right_child == nullptr)
            height = 0;

            // Otherwise, we only have the right subtree so
            // our height is one more than it's height.
        else
            height = right_child->height + 1;

        // Otherwise, the left subtree exists so if we
        // don't have a right one, our height is one
        // more than it's height.
    else if (right_child == nullptr)
        height = left_child->height + 1;

        // Otherwise, we have both subtree's so if the
        // left's height is greater than the right, our
        // height is one more than it.
    else if (left_child->height > right_child->height)
        height = left_child->height + 1;

        // Otherwise, the right subtree's height will be
        // used so our height is one more than it.
    else
        height = right_child->height + 1;
    return height;
} // updateHeight

// **************************************************
// AVLTree class methods.

// --------------------------------------------------
// Constructor to create an empty tree.
AVLTree::AVLTree() {
    count = 0;
    root = nullptr;
} // AVLTree

// --------------------------------------------------
// Constructor to populate the tree with one node.
AVLTree::AVLTree(Account account) {
    root = new Node(account);
} // AVLTree

// --------------------------------------------------
// Balance the subtree.
void AVLTree::balanceAtNode(Node* n) {

    // Get the current balance and if it is bad
    // enough on the left side, rotate it right
    // adjusting the subtree left, if required.
    int bal = n->getBalance();
    if (bal > 1) {
        if (n->getLeftChild()->getBalance() < 0)
            rotateLeft(n->getLeftChild());
        rotateRight(n);

        // Otherwise, if the balance is bad enough on
        // the right side, rotate it left adjusting the
        // subtree right, if required.
    }
    else if (bal < -1) {
        if (n->getRightChild()->getBalance() > 0)
            rotateRight(n->getRightChild());
        rotateLeft(n);
    } // if
} // balanceAtNode

// --------------------------------------------------
// Find the node containing the data.
AVLTree::Node* AVLTree::findNode(int val) {

    // While nodes remain, if we found the right
    // node, exit the loop. If the value we want
    // is less than the current, check the left
    // subtree, otherwise, the right.
    Node* temp = root;
    while (temp != nullptr) {
        if (val == temp->getData().getAccId()) {
            break;
        }
        else if (val < temp->getData().getAccId())
            temp = temp->getLeftChild();
        else
            temp = temp->getRightChild();
    } // while
    return temp;
} // findNode

// --------------------------------------------------
// --------------------------------------------------
// Find the node containing the data.
AVLTree::Node* AVLTree::updateNode(int val) {
    // While nodes remain, if we found the right
    // node, exit the loop. If the value we want
    // is less than the current, check the left
    // subtree, otherwise, the right.
    Node* temp = root;
    while (temp != nullptr) {
        if (val == temp->getData().getAccId()) {
            char choice = 'a';
            while (choice != 'd' && choice != 'c') {
                cout << "Would you like to debit or credit? Press D for debit, C for credit:  ";
                cin >> choice;
                if (choice == 'd' || choice == 'D') {
                    double amount;
                    double balance = temp->getData().getAccBalance();
                    cout << "Name: " << temp->getData().getFirstName() << " " << temp->getData().getLastName() << endl;
                    cout << "Current balance: " << temp->getData().getAccBalance() << endl;
                    cout << "Enter amount to debit: ";
                    cin >> amount;
                    balance = balance - amount;
                    //cout << balance << endl;
                    temp->byPointerData()->setAccBalance(balance);
                    //cout << "Update: " << temp->getData().getAccBalance();
                }
                else if (choice == 'c' || choice == 'C') {
                    double amount;
                    double balance = temp->getData().getAccBalance();
                    cout << "Name: " << temp->getData().getFirstName() << " " << temp->getData().getLastName() << endl;
                    cout << "Current balance: " << balance << endl;
                    cout << "Enter amount to credit: ";
                    cin >> amount;
                    balance = balance + amount;
                    //cout << balance << endl;
                    temp->byPointerData()->setAccBalance(balance);
                    //cout << "Update: " << temp->getData().getAccBalance();
                }
                else {
                    cout << "Invalid Input." << endl;
                    cout << "Re-enter: " << endl;
                }
            }
            cout<<"here.";
            fstream file;
            ofstream newfile;
            file.open("newdata.txt", ios::in | ios::out | ios::app);
            newfile.open("temp.txt", ios::out);
            double value = -1.0;
            string temporary;
            int count = 1;
            while (value != temp->byPointerData()->getAccId()) {
                if (count == 1 || count == 2) {
                    file >> value;
                    newfile << value << "\t\t";
                    count++;
                }
                else if (count == 3 || count == 4) {
                    file >> temporary;
                    newfile << temporary << "\t\t";
                    count++;

                }
                else {
                    file >> value;
                    newfile << value << "\n";
                    count = 1;
                }
            }

            file >> temporary;
            newfile << temporary << "\t\t";
            count++;

            file >> temporary;
            newfile << temporary << "\t\t";
            count++;

            file >> value;
            newfile << temp->byPointerData()->getAccBalance();
            count++;

            while (!file.eof()) {
                if (count == 1 || count == 2) {
                    file >> value;
                    newfile << value << "\t\t";
                    count++;
                }
                else if (count == 3 || count == 4) {
                    file >> temporary;
                    newfile << temporary << "\t\t";
                    count++;
                }
                else if(count==5){
                    file >> value;
                    newfile << value<<" ";
                    count ++;
                }
                else {
                    newfile << "\n";
                    count = 1;
                }
            }
            file.close();
            newfile.close();
            std::remove("newdata.txt");
            std::rename("temp.txt", "newdata.txt");
            break;
        }
        else if (val < temp->getData().getAccId())
            temp = temp->getLeftChild();
        else
            temp = temp->getRightChild();
    } // while



    return temp;



} // updateNode

// --------------------------------------------------
// Get the tree's height.
int AVLTree::getHeight() {
    return root->getHeight();
} // getHeight

// --------------------------------------------------
// Insert the value into the tree.
// Returns:
//		 true: If addition is successful
//		 false: If item already exists
//
bool AVLTree::insert(Account acc) {

    // If the tree is empty, add the new node as the
    // root.
    if (root == nullptr)
        root = new Node(acc);

        // Otherwise, we need to find the insertion point.
    else {

        // Starting at the tree root search for the
        // insertion point, until we have added the
        // new node.
        Node* added_node = nullptr;
        Node* temp = root;
        while (temp != nullptr && added_node == nullptr) {

            // If the value is less than the current
            // node's value, go left. If there isn't a
            // left subtree, insert the node, otherwise,
            // it is next to check.
            if (acc.getAccId() < temp->getData().getAccId()) {
                if (temp->getLeftChild() == nullptr) {
                    added_node = temp->setLeftChild(
                            new Node(acc));
                }
                else
                    temp = temp->getLeftChild();

                // Otherwise, if the value is greater than
                // the current node's value, go right. If
                // there isn't a right subtree, insert the
                // node, otherwise, it is next to check.
            }
            else if (acc.getAccId() > temp->getData().getAccId()) {
                if (temp->getRightChild() == nullptr) {
                    added_node = temp->setRightChild(
                            new Node(acc));
                }
                else
                    temp = temp->getRightChild();

                // Otherwise, the value is already in the
                // tree so abort.
            }
            else
                return false;
        } // while

        // From the new node upwards to the root,
        // updated the height and make sure the
        // subtree is balanced.
        temp = added_node;
        while (temp != nullptr) {
            temp->updateHeight();
            balanceAtNode(temp);
            temp = temp->getParent();
        } // while
    } // if
    count++;
    return true;
} // insert

// --------------------------------------------------
// Print the tree in this pattern complaining if
// too deep or empty.
//			  08
//	  04			  12
//  02	  06	  10	  14
//01  03  05  07  09  11  13  15
void AVLTree::print() {

    // If the tree is empty, say so.
    if (root == nullptr)
        std::cout << "Tree is empty!" <<
                  std::endl;

        // Otherwise, if the tree has a height more than 4
        // (5 rows), it is too wide.
    else if (root->getHeight() > 4)
        std::cout << "Not currently supported!" <<
                  std::endl;

        // Otherwise, set up to display the tree. Get
        // the maximum depth and for each possible
        // level, output that level's elements and
        // finish off the line.
    else {
        int max = root->getHeight();
        for (int depth = 0; depth <= max; depth++) {
            printSubtree(root, depth, max - depth + 1, true);
            std::cout << std::endl;
        } // for
    } // if
} // print

// --------------------------------------------------
// Print the subtree.  The leftmost branch will have
// first true. The level counts up from the bottom
// for the line we are doing. The depth is how
// many layers to skip over.
void AVLTree::printSubtree(Node* subtree, int depth,
                           int level, bool first) {

    // If we need to go deeper in the subtree, do so.
    // If the subtree is empty, pass it down, otherwise
    // pass both left and right subtrees.
    if (depth > 0) {
        if (subtree == nullptr) {
            printSubtree(subtree, depth - 1, level, first);
            printSubtree(subtree, depth - 1, level, false);
        }
        else {
            printSubtree(subtree->getLeftChild(), depth - 1,
                         level, first);
            printSubtree(subtree->getRightChild(), depth - 1,
                         level, false);
        } // if

        // Otherwise, if the subtree is empty, display
        // an empty element. The leftmost element only
        // needs half the spacing.
    }
    else if (subtree == nullptr)
        std::cout << std::setw((first) ?
                               spacing(level) / 2 : spacing(level)) << "-";

        // Otherwise, we have a live element so display
        // it. Once more, use half spacing for the
        // leftmost element.
    else
        std::cout << std::setw((first) ?
                               spacing(level) / 2 : spacing(level)) <<
                  subtree->getData().getAccId();
} // printSubtree

// --------------------------------------------------
// Remove the value from the tree.
// Returns:
//		 true: If removal is successful
//		 false: If item is not found in the tree
//
bool AVLTree::remove(Account acc) {

    // Find the node to delete and if none, exit.
    Node* toBeRemoved = findNode(acc.getAccId());
    if (toBeRemoved == nullptr)
        return false;

    // Get the parent and set the side the node is
    // on of the parent.
    enum { left, right } side;
    Node* p = toBeRemoved->getParent();
    if (p != nullptr &&
        p->getLeftChild() == toBeRemoved)
        side = left;
    else
        side = right;

    // If the node to be removed doesn't have a left
    // subtree, check it's right subtree to figure
    // out our next move.
    if (toBeRemoved->getLeftChild() == nullptr)

        // If we don't have any subtrees, we are the
        // leaf so our parent doesn't need us.
        if (toBeRemoved->getRightChild() == nullptr) {

            // If we don't have a parent, the tree is now
            // empty so change the root to null and delete
            // our node.
            if (p == nullptr) {
                setRoot(nullptr);
                delete toBeRemoved;

                // Otherwise, change the parent so it doesn't
                // point to us, delete ourself, update the
                // parent's height, and rebalance the tree.
            }
            else {
                if (side == left)
                    p->setLeftChild(nullptr);
                else
                    p->setRightChild(nullptr);
                delete toBeRemoved;
                p->updateHeight();
                balanceAtNode(p);
            } // if

            // Otherwise, there is a right subtree so use
            // it to replace ourself.
        }
        else {

            // If we don't have a parent, the tree is now
            // the right subtree and delete our node.
            if (p == nullptr) {
                setRoot(toBeRemoved->getRightChild());
                delete toBeRemoved;

                // Otherwise, change the parent so it doesn't
                // point to us, delete ourself, update the
                // parent's height, and rebalance the tree.
            }
            else {
                if (side == left)
                    p->setLeftChild(toBeRemoved->
                            getRightChild());
                else
                    p->setRightChild(toBeRemoved->
                            getRightChild());
                delete toBeRemoved;
                p->updateHeight();
                balanceAtNode(p);
            } // if
        } // if

        // Otherwise, we have a left subtree so check the
        // right one of the node being removed to decide
        // what is next. If there isn't a right subtree,
        // the left one will replace ourself.
    else if (toBeRemoved->getRightChild() ==
             nullptr) {

        // If we don't have a parent, the tree is now
        // the left subtree and delete our node.
        if (p == nullptr) {
            setRoot(toBeRemoved->getLeftChild());
            delete toBeRemoved;

            // Otherwise, change the parent so it doesn't
            // point to us, delete ourself, update the
            // parent's height, and rebalance the tree.
        }
        else {
            if (side == left)
                p->setLeftChild(toBeRemoved->
                        getLeftChild());
            else
                p->setRightChild(toBeRemoved->
                        getLeftChild());
            delete toBeRemoved;
            p->updateHeight();
            balanceAtNode(p);
        } // if

        // Otherwise, the node to remove has both subtrees
        // so decide the best method to remove it.
    }
    else {

        // Check the balance to see which way to go.
        // If the left side is deeper, modify it.
        Node* replacement;
        Node* replacement_parent;
        Node* temp_node;
        int bal = toBeRemoved->getBalance();
        if (bal > 0) {

            // If the right subtree of the node's
            // left subtree is empty, we can move the
            // node's right subtree there.
            if (toBeRemoved->getLeftChild()->
                    getRightChild() == nullptr) {
                replacement = toBeRemoved->getLeftChild();
                replacement->setRightChild(
                        toBeRemoved->getRightChild());
                temp_node = replacement;

                // Otherwise, find the right most empty subtree
                // of our node's left subtree and it's
                // parent. This is our replacement. Make it's
                // parent point to it's left child instead
                // of itself. It is now free to replace the
                // deleted node. Copy both of the deleted
                // nodes subtrees into the replacement leaving
                // fixing up the parent below.
            }
            else {
                replacement = toBeRemoved->
                        getLeftChild()->getRightChild();
                while (replacement->getRightChild() !=
                       nullptr)
                    replacement = replacement->getRightChild();
                replacement_parent = replacement->getParent();
                replacement_parent->setRightChild(
                        replacement->getLeftChild());
                temp_node = replacement_parent;
                replacement->setLeftChild(
                        toBeRemoved->getLeftChild());
                replacement->setRightChild(
                        toBeRemoved->getRightChild());
            } // if

            // Otherwise, we are going to modify the right
            // side so, if the left subtree of the node's
            // right subtree is empty, we can move the
            // node's left subtree there.
        }
        else if (toBeRemoved->getRightChild()->
                getLeftChild() == nullptr) {
            replacement = toBeRemoved->getRightChild();
            replacement->setLeftChild(
                    toBeRemoved->getLeftChild());
            temp_node = replacement;

            // Otherwise, find the left most empty subtree
            // of our node's right subtree and it's
            // parent. This is our replacement. Make it's
            // parent point to it's right child instead
            // of itself. It is now free to replace the
            // deleted node. Copy both of the deleted
            // nodes subtrees into the replacement leaving
            // fixing up the parent below.
        }
        else {
            replacement = toBeRemoved->
                    getRightChild()->getLeftChild();
            while (replacement->getLeftChild() !=
                   nullptr)
                replacement = replacement->getLeftChild();
            replacement_parent = replacement->getParent();
            replacement_parent->setLeftChild(
                    replacement->getRightChild());
            temp_node = replacement_parent;
            replacement->setLeftChild(
                    toBeRemoved->getLeftChild());
            replacement->setRightChild(
                    toBeRemoved->getRightChild());
        } // if

        // Fix the parent to point to the new root.
        // If there isn't a parent, update the actual
        // tree root. Otherwise, there is a parent so
        // if we were the left subtree, update it,
        // otherwise, the right. In all cases, delete
        // the node and rebalance the tree.
        if (p == nullptr)
            setRoot(replacement);
        else if (side == left)
            p->setLeftChild(replacement);
        else
            p->setRightChild(replacement);
        delete toBeRemoved;
        balanceAtNode(temp_node);
    } // if
    count--;
    return true;
} // remove

// --------------------------------------------------
// Rotate the subtree left.
void AVLTree::rotateLeft(Node* n) {

    // Get the node's parent and if it exists and the
    // node was it's left subtree, remember we are
    // processing the left, otherwise, the right.
    enum { left, right } side;
    Node* p = n->getParent();
    if (p != nullptr && p->getLeftChild() == n)
        side = left;
    else
        side = right;

    // Get the node's right subtree as the new root
    // and that subtree's left subtree. Make that
    // left subtree the node's new right. Put our
    // original node as the left subtree of our
    // new root.
    Node* temp = n->getRightChild();
    n->setRightChild(temp->getLeftChild());
    temp->setLeftChild(n);

    // Fix the original parent to point to the new
    // root. If there isn't a parent, update the
    // actual tree root. Otherwise, there is a
    // parent so if we were the left subtree, update
    // it, otherwise, the right.
    if (p == nullptr)
        setRoot(temp);
    else if (side == left)
        p->setLeftChild(temp);
    else
        p->setRightChild(temp);
} // rotateLeft

// --------------------------------------------------
// Rotate the subtree left.
void AVLTree::rotateRight(Node* n) {

    // Get the node's parent and if it exists and the
    // node was it's left subtree, remember we are
    // processing the left, otherwise, the right.
    enum { left, right } side;
    Node* p = n->getParent();
    if (p != nullptr && p->getLeftChild() == n)
        side = left;
    else
        side = right;

    // Get the node's left subtree as the new root
    // and that subtree's right subtree. Make that
    // right subtree the node's new left. Put our
    // original node as the right subtree of our
    // new root.
    Node* temp = n->getLeftChild();
    n->setLeftChild(temp->getRightChild());
    temp->setRightChild(n);

    // Fix the original parent to point to the new
    // root. If there isn't a parent, update the
    // actual tree root. Otherwise, there is a
    // parent so if we were the left subtree, update
    // it, otherwise, the right.
    if (p == nullptr)
        setRoot(temp);
    else if (side == left)
        p->setLeftChild(temp);
    else
        p->setRightChild(temp);
} // rotateRight

// --------------------------------------------------
// Set the root. Change the tree root to the node
// and if it exists, remove it's parent.
void AVLTree::setRoot(Node* n) {
    root = n;
    if (root != nullptr)
        root->removeParent();
} // setRoot

// --------------------------------------------------
// Figure out the default spacing for element. Each
// higher level doubles the preceeding. The bottom
// level is one.
int AVLTree::spacing(int level) {
    int result = 2;
    for (int i = 0; i < level; i++)
        result += result;
    return result;
} // spacing

void AVLTree::showStructure() const {
    if (root == 0)
        cout << "Empty tree" << endl;
    else
    {
        cout << endl;
        showHelper(root, 1);
        cout << endl;
    }
    cout << "Height of tree: " << root->getHeight() << endl;
}

void AVLTree::showHelper(Node* p, int level) const

// Recursive helper for showStructure.
// Outputs the subtree whose root node is pointed to by p.
// Parameter level is the level of this node within the tree.

{
    int j;   // Loop counter

    if (p != 0)
    {
        showHelper(p->getRightChild(), level + 1);         // Output right subtree
        for (j = 0; j < level; j++)    // Tab over to level
            cout << "\t";
        cout << " " << p->getData().getAccId();   // Output key
        if ((p->getLeftChild() != 0) &&           // Output "connector"
            (p->getRightChild() != 0))
            cout << "<";
        else if (p->getRightChild() != 0)
            cout << "/";
        else if (p->getLeftChild() != 0)
            cout << "\\";
        cout << endl;
        showHelper(p->getLeftChild(), level + 1);          // Output left subtree
    }
}

void AVLTree::displayInOrder(Node* nodePtr) const
{
    if (nodePtr)
    {
        displayInOrder(nodePtr->getLeftChild());
        nodePtr->getData().display(); cout << endl << endl;
        displayInOrder(nodePtr->getRightChild());
    }
}



// **************************************************
// Test the class.
int main() {
    AVLTree* tree = new AVLTree();
    Account a1;
    double val = 0.0;
    string str = "";

    ifstream file;
    file.open("newdata.txt");
    if (file) {

        while (!file.eof()) {
            file >> val;
            a1.setRecNum(int(val));

            file >> val;
            a1.setAccId(long(val));

            file >> str;
            a1.setFirstName(str);

            file >> str;
            a1.setLastName(str);

            file >> val;
            a1.setAccBalance(val);

            tree->insert(a1);
        }



    }
    else {
        cout << "File not found!";
        return 1;
    }
    file.close();

    char choice;
    cout << "Press A for account information display" << endl;
    cout << "Press N for adding new node to the tree" << endl;
    cout << "Press S to show structure of the tree" << endl;
    cout << "Press O to display all accounts, in ascending order of account IDs" << endl;
    cout << "Press X for debit/credit money from an account" << endl;
    cout << "Press Q to exit" << endl << endl;
    cout << "Input choice: ";
    cin >> choice;
    while (choice != 'q' && choice != 'Q') {
        if (choice == 's' || choice == 'S') {
            tree->showStructure();
            cout << endl << endl;
        }
        else if (choice == 'o' || choice == 'O') {
            tree->displayInOrder();
        }
        else if (choice == 'a' || choice == 'A') {
            int id;
            cout << "Input Account ID number: ";
            cin >> id;
            tree->find(id);
            cout << endl;
        }
        else if (choice == 'n' || choice == 'N') {
            cout << endl;
            int accountID;
            string firstName, lastName;
            double accountBalance;
            cout << "Enter Information For The New Account!" << endl;
            cout << "Account ID: ";
            cin >> accountID;
            cout << "First Name: ";
            cin >> firstName;
            cout << "Last Name: ";
            cin >> lastName;
            cout << "Account balance: ";
            cin >> accountBalance;
            int recordNum = tree->getCount();
            Account a2(accountID, firstName, lastName, accountBalance);
            a2.setRecNum(recordNum);
            tree->insert(a2);
            cout << "Tree Updated!" << endl;

            ofstream writeFile;
            writeFile.open("newdata.txt", ios::out | ios::app);
            writeFile << endl;
            writeFile << recordNum << "\t\t";
            writeFile << accountID << "\t\t";
            writeFile << firstName << "\t\t";
            writeFile << lastName << "\t\t";
            writeFile << accountBalance ;
            writeFile.close();
        }
        else if (choice == 'x' || choice == 'X') {
            int id;
            cout << "Input Account ID number: ";
            cin >> id;
            tree->update(id);




        }
        else {
            cout << "Invalid Input." << endl;
        }
        cout << endl;
        cout << "Input next choice: ";
        cin >> choice;
    }

    return 0;
}