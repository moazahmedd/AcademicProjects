package com.project.barberreservationsystem;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BarberReservationSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
