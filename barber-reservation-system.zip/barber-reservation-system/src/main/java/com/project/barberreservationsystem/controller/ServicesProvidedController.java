package com.project.barberreservationsystem.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.project.barberreservationsystem.model.ServicesProvided;
import com.project.barberreservationsystem.service.ServService;

@Controller
public class ServicesProvidedController {
	@Autowired
	ServService servicesprovided;

	@RequestMapping("redirectAddServices")
	public String redirectingToAddServicePage() {
		return "addService";
	}
	

	@PostMapping("addService")
	public String addService(ServicesProvided service) {
		servicesprovided.addingService(service);
		return "admin";
	}
	

	@RequestMapping("redirectDisplayServices")
	public String redirectingToDisplayServicePage(Model model) {
		model.addAttribute("services",servicesprovided.displayServicesProvided());
		return "displayService";
	}
	
}
