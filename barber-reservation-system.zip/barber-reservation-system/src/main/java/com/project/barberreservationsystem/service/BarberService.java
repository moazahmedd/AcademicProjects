package com.project.barberreservationsystem.service;

import java.util.List;

import com.project.barberreservationsystem.model.Barber;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.barberreservationsystem.repository.IBarberRepository;

import lombok.extern.slf4j.Slf4j;

@Service

public class BarberService {
	
	@Autowired
	IBarberRepository barberRepository;

	public boolean addingBarber(Barber barber) {
		barberRepository.save(new Barber(barber.getName(),barber.getSpeciality()));
		return true;
	}
	

	public List<Barber> displayBarber(){
		return barberRepository.findAll();
	}
	
	
}
