package com.project.barberreservationsystem.repository;

import com.project.barberreservationsystem.model.Barber;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IBarberRepository extends JpaRepository<Barber,Integer> {
	
	
}
