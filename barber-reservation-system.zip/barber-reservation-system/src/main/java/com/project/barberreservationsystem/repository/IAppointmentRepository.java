package com.project.barberreservationsystem.repository;

import java.util.List;

import com.project.barberreservationsystem.model.Appointment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface IAppointmentRepository extends JpaRepository<Appointment,Integer> {
	
	@Query("SELECT a FROM Appointment a WHERE CONCAT(a.barberName,' ', a.status ,' ',a.date,'',a.time,'',a.service,'',a.total_cost,'') LIKE %:searchedKeyword%")
	List<Appointment> findByBarberNameService(@Param("searchedKeyword")String searchKeyword);
	
	

	List<Appointment> findByCustomerID(int customerid);



	List<Appointment> findBybarberName(String barberName);

}
