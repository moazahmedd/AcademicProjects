package com.project.barberreservationsystem.service;

import java.util.List;
import java.util.Optional;

import com.project.barberreservationsystem.model.RegistrationForm;
import com.project.barberreservationsystem.repository.IUserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.project.barberreservationsystem.model.User;

import org.springframework.ui.Model;


@Service
public class UserService {
	
	@Autowired
    IUserRepository userRepository;
	
	BCryptPasswordEncoder bCrypt=new BCryptPasswordEncoder();

	public boolean verifyConfirmPassword(RegistrationForm registrationForm, Model model) {
		boolean passwordMatchCheck = registrationForm.getPassword().equals(registrationForm.getConfirmPassword());
		if (!passwordMatchCheck){
			model.addAttribute("errorMessage","Passwords do not match!");
		}
		return passwordMatchCheck;
	}

	public boolean verifyUsername(RegistrationForm registrationForm, Model model) {
		boolean check = userRepository.findByUsername(registrationForm.getUsername()).isPresent();
		if (check){
			model.addAttribute("errorMessage","User Already Exists!");
			return false;
		}
		return true;
	}

	public boolean verifyRole(String username) {
		User foundUser=userRepository.findByUsername(username).get();
		if (foundUser.getUsername().contains("admin")) {
			foundUser.setRole(true);
			userRepository.save(foundUser);
			return true;
		}
		else {
			return false;
		}
		
	}

	public boolean checkIfAdmin(String username) {
		return userRepository.findByUsername(username).get().isRole();
	}

	public boolean registerUser(RegistrationForm registrationForm,User user, Model model) {
		if (verifyConfirmPassword(registrationForm, model) && verifyUsername(registrationForm, model)) {
			userRepository.save(new User(registrationForm.getUsername(),bCrypt.encode(registrationForm.getPassword()),registrationForm.getFirstname(),registrationForm.getLastname(),registrationForm.getEmail(),user.isRole()));
			return true;
		}
		else {
			return false;
		}
	}

	public boolean loginUser(User user) {
		Optional<User> foundUserOptional=userRepository.findByUsername(user.getUsername());
		if (foundUserOptional.isPresent()) {
			User foundUser=foundUserOptional.get();
			return bCrypt.matches(user.getPassword(),foundUser.getPassword());
			
			
		}
		return false;
	}

	public boolean authenticateUser(String sessionUsername) {
		
		return userRepository.findByUsername(sessionUsername).isPresent()?true:false;
	}

	public List<User> showDetails(User user) {
		//log.info("Returning all user details from repository");
		return userRepository.findAll();
	}

	public List<User> displayCustomerDetails(String customerUserName){
		//log.info("Returning user details from repository");
		int customerId=userRepository.findByUsername(customerUserName).get().getId();
		return userRepository.findById(customerId);
		
	}
}
