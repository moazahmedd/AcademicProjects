package com.project.barberreservationsystem.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.project.barberreservationsystem.model.ServicesProvided;

@Repository
public interface IServiceRepository extends JpaRepository<ServicesProvided,Integer>{

}
