package com.project.barberreservationsystem.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Appointment")
public class Appointment {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private String date;
	private String time;
	private String barberName;
	private String service;
	private boolean status=true;
	private String total_cost;
	private int customerID;
	
	public Appointment() {
		
	}
	
	
	public Appointment(String date, String time, String barberName, String service, boolean status, String total_cost,
			int customerID) {
		super();
		this.date = date;
		this.time = time;
		this.barberName = barberName;
		this.service = service;
		this.status = status;
		this.total_cost = total_cost;
		this.customerID = customerID;
	}

	
	public int getCustomerID() {
		return customerID;
	}


	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}


	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}

	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	
	public String getTotal_cost() {
		return total_cost;
	}
	public void setTotal_cost(String total_cost) {
		this.total_cost = total_cost;
	}

	public String getBarberName() {
		return barberName;
	}

	public void setBarberName(String barberName) {
		this.barberName = barberName;
	}

	public String getService() {
		return service;
	}

	public void setService(String service) {
		this.service = service;
	}

	@Override
	public String toString() {
		return "Appointment [id=" + id + ", date=" + date + ", time=" + time + ", barberName=" + barberName
				+ ", service=" + service + ", status=" + status + ", total_cost=" + total_cost + "]";
	}



	
	
	
	
	
	
	
}
