package com.project.barberreservationsystem.controller;

import javax.servlet.http.HttpServletRequest;

import com.project.barberreservationsystem.model.RegistrationForm;
import com.project.barberreservationsystem.model.User;
import com.project.barberreservationsystem.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
public class UserController {
	
	
	
	@Autowired
    UserService userService;
	

	@RequestMapping("login")
	public String goToLogin() {
		return "login";
	}
	

	@RequestMapping("register")
	public String goToRegister() {
		return "register";
	}
	
	@RequestMapping("redirectIndexPage")
	public String goToIndex() {
		return "index";
	}
	
	@RequestMapping("redirectAboutUsPage")
	public String goToAboutUsPage() {
		return "aboutUs";
	}
	
	@RequestMapping("redirectServicePage")
	public String goToServicePage() {
		return "displayService";
	}
	

	@PostMapping("registerUser")
	public String registerUser(Model model, RegistrationForm registrationForm, User user) {
//		Registering user...
		model.addAttribute("errorMessage", null);
		System.out.println(registrationForm.toString());
		if (userService.registerUser(registrationForm,user, model)) {
//			User successfully registered.Directing to log in page
			return "login";
		}
		else {
//			Invalid credentials at registration page
			return "register";
		}
	}
	

	@PostMapping("loginUser")
	public String loginUser(HttpServletRequest request,Model model,User user) {
		System.out.println("Loggin in user...");
		model.addAttribute("errorMessage",null);
		if(userService.loginUser(user) && userService.verifyRole(user.getUsername())) {
//			Admin logged in
			request.getSession().setAttribute("username",user.getUsername());
			return "admin";
		}
		else if(userService.loginUser(user)) {
//			Customer logged in
			request.getSession().setAttribute("username",user.getUsername());
			return "redirect:customerMainPage";
		}
		else {
//			Invalid credentials at login page.
			model.addAttribute("errorMessage","Invalid credentials!");
			return "login";
		}
		
	}
	

	@RequestMapping("customerMainPage")
	public String redirectingToCustomerMainPage(HttpServletRequest request,Model model) {
		String username=(String) request.getSession().getAttribute("username");
		model.addAttribute("username",username);
		return userService.authenticateUser(username)?"customerMainPage":"error";
	}
	

	@RequestMapping("logout")
	public String redirectingToIndexPage(HttpServletRequest request) {
		request.getSession().invalidate();
		return "index";
	}
	

	@RequestMapping("showCustomerDetails")
	public String redirectingToUserDetailPage(Model model,User user,HttpServletRequest request) {
		String username = (String) (request.getSession().getAttribute("username"));
		if (userService.checkIfAdmin(username)) {
			model.addAttribute("user",userService.showDetails(user));
		}
		else {
			model.addAttribute("user",userService.displayCustomerDetails(username));
		}
		
		return "detailsPage";
	}
}
