package com.project.barberreservationsystem.controller;

import com.project.barberreservationsystem.model.Barber;
import com.project.barberreservationsystem.service.BarberService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class BarberController {
	@Autowired
    BarberService barberservice;

	@RequestMapping("redirectAddBarber")
	public String redirectingToAddBarberPage() {
		return "addBarber";
	}

	@PostMapping("addBarber")
	public String addBarber(Barber barber) {
		barberservice.addingBarber(barber);
		return "admin";
	}
	

	@RequestMapping("redirectDisplayBarber")
	public String redirectingToDisplayBarberPage(Model model) {
		model.addAttribute("barbers",barberservice.displayBarber());
		return "displayBarber";
	}
}
