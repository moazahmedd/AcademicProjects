package com.project.barberreservationsystem.service;

import java.util.List;

import com.project.barberreservationsystem.model.ServicesProvided;
import com.project.barberreservationsystem.repository.IServiceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import lombok.extern.slf4j.Slf4j;


@Service
public class ServService {
	
	@Autowired
    IServiceRepository serviceRepository;

	public boolean addingService(ServicesProvided service) {
		serviceRepository.save(new ServicesProvided(service.getServiceName(),service.getServiceCost()));
		return true;
	}
	

	public List<ServicesProvided> displayServicesProvided(){
		return serviceRepository.findAll();
	}
}
