package com.project.barberreservationsystem.service;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import com.project.barberreservationsystem.model.Appointment;
import com.project.barberreservationsystem.repository.IUserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.barberreservationsystem.repository.IAppointmentRepository;

@Service
public class AppointmentService {
	
	@Autowired
	IAppointmentRepository appointmentRepository;
	
	@Autowired
	IUserRepository userRepository;

	public boolean addingAppointment(Appointment appointment, String customerUserName) {
		int customerid=userRepository.findByUsername(customerUserName).get().getId();
		if (verifyAppointmentAvailability(appointment)) {
			//log.info("Saving appointment details");
			appointmentRepository.save(new Appointment(appointment.getDate(),appointment.getTime(),appointment.getBarberName(),appointment.getService().split(" ")[1],appointment.isStatus(),appointment.getService().split(" ")[0],customerid));
			return true;
		}
		else {
			return false;
		}
	}

	public List<Appointment> displayAppointment(){
		//log.info("Returning all appointments from repository");
		return appointmentRepository.findAll();
	}

	public List<Appointment> displayCustomerAppointment(String customerUserName){
		int customerid=userRepository.findByUsername(customerUserName).get().getId();
		//log.info("Returning customer appointments from repository");
		System.out.println(appointmentRepository.findByCustomerID(customerid));
		return appointmentRepository.findByCustomerID(customerid);
		
	}

	public List<Appointment> searchAppointment(String searchKeyword){
		//log.info("Returning search appointment according to searchedKeyword from repository" );
		return appointmentRepository.findByBarberNameService(searchKeyword);
	}

	public boolean cancelAppointment(Integer ID) {
		//log.info("Returning cancelled appointment details from appointment repository");
		Appointment appointment=appointmentRepository.findById(ID).get();
		appointment.setStatus(false);
		appointmentRepository.save(appointment);
		return false;

	}

	public boolean verifyAppointmentAvailability(Appointment appointment) {
		List<Appointment> appointments=appointmentRepository.findBybarberName(appointment.getBarberName());
		if (appointments.isEmpty()) {
			return true;
		}
		LocalTime timetoCheck = null;
		LocalTime appointmentAdded30 = null;
		LocalTime appointmentSubtract30=null;
		boolean differentDate = false;
		for (Appointment foundAppointment:appointments) {
				if(foundAppointment.getDate().equals(appointment.getDate())==false) {
					differentDate=true;
					return true;
				}
				if (foundAppointment.getDate().equals(appointment.getDate())) {
					DateTimeFormatter df=DateTimeFormatter.ofPattern("HH:mm");
					LocalTime appointmentTime=LocalTime.parse(foundAppointment.getTime());
					
					appointmentAdded30=LocalTime.parse(df.format(appointmentTime.plusMinutes(30)));
					
					appointmentSubtract30=LocalTime.parse(df.format(appointmentTime.minusMinutes(30)));
					timetoCheck=LocalTime.parse(appointment.getTime());
								
				}
		}
		
		if (timetoCheck.isAfter(appointmentAdded30) || timetoCheck.isBefore(appointmentSubtract30)) {
			//log.info("Barber available on the time selected by user");
			return true;
		}
		
		
		return false;
	}




}
