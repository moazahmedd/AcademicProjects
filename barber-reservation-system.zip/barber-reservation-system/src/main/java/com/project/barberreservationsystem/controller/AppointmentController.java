package com.project.barberreservationsystem.controller;

import javax.servlet.http.HttpServletRequest;

import com.project.barberreservationsystem.model.Appointment;
import com.project.barberreservationsystem.service.AppointmentService;
import com.project.barberreservationsystem.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.project.barberreservationsystem.service.BarberService;
import com.project.barberreservationsystem.service.ServService;


@Controller
public class AppointmentController {

	@Autowired
	BarberService barberService;

	@Autowired
	ServService service;

	@Autowired
	AppointmentService appointmentService;

	@Autowired
	UserService userService;


	@RequestMapping("redirectAddAppointments")
	public String redirectingToAddAppointmentPage(Model model) {
		model.addAttribute("barbers", barberService.displayBarber());
		model.addAttribute("services", service.displayServicesProvided());
		return "newAppointment";
	}

	@PostMapping("addAppointment")
	public String addAppointment(Appointment appointment, Model model, HttpServletRequest request) {
		//log.info("Adding appointment");
		String username = (String) (request.getSession().getAttribute("username"));
		if (appointmentService.addingAppointment(appointment,username)) {
			if (userService.checkIfAdmin(username)) {
				model.addAttribute("appointments", appointmentService.displayAppointment());
			//	Displaying appointment after successful booking
				return "displayAppointments";
			}
			else if(!userService.checkIfAdmin(username)) {
				model.addAttribute("appointments", appointmentService.displayCustomerAppointment(username));
			//	Displaying appointment after successful booking
				return "displayAppointments";
			}
		}
		 else {
		//	Barber not available at user selected time
			model.addAttribute("errorMessage", "Barber is not available at the selected time.");
			model.addAttribute("barbers", barberService.displayBarber());
			model.addAttribute("services", service.displayServicesProvided());
			return "newAppointment";
		}
	
		return "newAppointment";
	}


	@RequestMapping("redirectDisplayAppointments")
	public String displayAppointment(Model model, Appointment appointment, HttpServletRequest request) {
		String username = (String) (request.getSession().getAttribute("username"));

		if (userService.checkIfAdmin(username)) { // if admin,return all appointments
			model.addAttribute("appointments", appointmentService.displayAppointment());
		}

		else {  //if customer, show only his appointments
			model.addAttribute("appointments", appointmentService
					.displayCustomerAppointment(username));
		}

		return "displayAppointments";

	}

	@RequestMapping("redirectSearchAppointments")
	public String redirectingToSearchAppointmentPage() {
		return "searchAppointment";
	}


	@RequestMapping("searchAppointment")
	public String searchAppointment(Model model, @RequestParam String searchKeyword) {
		if (searchKeyword != null) {
			model.addAttribute("appointments", appointmentService.searchAppointment(searchKeyword));
		}
		return "searchAppointment";
	}

	@RequestMapping("redirectCancelAppointments")
	public String redirectingToCancelAppointment(Model model,HttpServletRequest request) {
		//log.info("Redirecting to cancelling appointment");
		String username = (String) (request.getSession().getAttribute("username"));
		if (userService.checkIfAdmin(username)) {
		//	Redirecting to display all appointments after cancellation
			model.addAttribute("appointments", appointmentService.displayAppointment());
		}
		else {
		//	Redirecting to display customer appointments after cancellation
			model.addAttribute("appointments", appointmentService.displayCustomerAppointment(username));
		}
		
		
		return "cancelAppointment";
	}

	@PostMapping("cancelAppointment")
	public String cancelAppointmentofCustomer(String ID,Model model,Appointment appointment,HttpServletRequest request) {
		//Cancelling appointment of customer
		System.out.println(ID);
		appointmentService.cancelAppointment(Integer.parseInt(ID));
		displayAppointment(model, appointment, request);
		return "displayCancelledAppointments";
	}

}
