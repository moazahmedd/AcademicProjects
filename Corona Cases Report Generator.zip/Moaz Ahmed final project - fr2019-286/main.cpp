#include<iostream>
#include<fstream>
#include<string>
using namespace std;

//LOGIN MENU
void name(); //Program name
char login_main(); //Main menu

//ADMIN PASS VALIDATION and MENU
void adminpassvalidate(); //Pass validate for admin function
int admin_options(); //admin menu
void adminoption1 (); //add tests conducted in current month
void adminoption2 (string areas[7]); //enter the additional cases of covid-19 in a particular area
int adminoption3 (); //Reports menu 
int adminoption4 (); //More Data menu

//ADMIN OPTION 4 FOR MORE DATA FUNCTIONS
void data_option1(string areas[]); //Total number of confirmed cases in an area
void data_option2(); //Total number of cases in country
void data_option3(); //Total number of deaths in country
void data_option4(string areas[]); //Number of new cases in any area (for May)

//ADMIN OPTION 3 FOR REPORT FUNCTIONS
void report_option1(float march_stats[], float april_stats[], string areas[]); //Percentage increase in corona spread in an area(month wise)
void report_option2(float march_stats[8], float april_stats[8]); //Percentage increase in deaths (between any 2 months)
void report_option3(float march_stats[8], float april_stats[8]); //Percentage increase in confirmed cases in country (between any two months)
void report_option4(); //Total number of recovered patients
void report_option5(); //Total number of tests conducted
void report_option6(); //Total number of deaths
void report_option7(); //Death rate
void report_option8(string areas[]); //Area with the highest number of cases
void report_option9(string areas[]); //Area with the minimum number of cases
void report_option10(float march_stats[],string areas[]); //Area with the highest rate of spread
void report_option11(float march_stats[],float april_stats[]); //Month with the highest number of deaths
void report_option12(float march_stats[],float april_stats[]); //Average number of cases in any month
void report_option13(float march_stats[], float april_stats[],string areas[]); //Average spread in an area over the three months
void report_option14(float march_stats[],string areas[]); //Area with the highest percentage increase (comparing Mar & May)
 
//PANEL FOR Medical Specialist AND linked functions 
int ms_options(); //Medical Specialist menu
void ms_options1(); //enter number of new deaths
void ms_options2(string areas[],float march_stats[],float april_stats[]); //enter number of new cases (area wise positive cases)
void ms_options3(); //enter number of new recovered patients in country

//PANEL FOR CITIZENS AND linked functions 
int citizen_options(); //citizen user menu
void citizen_options2(string areas[],float march_stats[],float april_stats[]); //reports for any particular area
void citizen_options3(string areas[],float march_stats[],float april_stats[]); //


int main(){
    string areas[7]={"sindh","punjab","kpk","balochistan","islamabad","gilgit","kashmir"};
    float march_stats[8]={676,1708,253,158,58,178,6,26}; //position 0-6:areas ... position7:deaths
    float april_stats[8]={6053-676,6340-1708,2313-253,1049-158,313-58,339-178,66-6,361-26}; //position 0-6:areas ... position7:deaths
    
    name();
    char login_input;
    int admin_option;

    login_input = login_main();  //input from main menu 
   
    if(login_input=='A' || login_input=='a'){
        system("CLS"); //to clear output screen 
        adminpassvalidate(); //to validate admin pass
        system("CLS");
        admin_option = admin_options(); //input from menu of admin panel
        system("CLS");
        if (admin_option==1){
           adminoption1(); 
        }
        
        else if(admin_option==2){
           adminoption2(areas);
        }
        
        else if(admin_option==3){
            int option3;
            option3 = adminoption3(); //input from reports menu
            
            if(option3==1){ 
                report_option1(march_stats,april_stats,areas);
            }
            
            else if(option3==2){
                report_option2(march_stats,april_stats);
            }
            
            else if(option3==3){
                report_option3(march_stats,april_stats);
            }
            
            else if(option3==4){
                report_option4();
            }
            
            else if(option3==5){
                report_option5();
            }
            
            else if(option3==6){
                report_option6();
            }
            
            else if(option3==7){
                report_option7();
            }
            
            else if(option3==8){
                report_option8(areas);
            }
            
            else if(option3==9){
                report_option9(areas);
            }
            
            else if(option3==10){
                report_option10(march_stats,areas);
            }
            
            else if(option3==11){
                report_option11(march_stats,april_stats);
            }
            
            else if(option3==12){
                report_option12(march_stats,april_stats);
            }
            
            else if(option3==13){
                report_option13(march_stats,april_stats,areas);
            }
            
            else if(option3==14){
                report_option14(march_stats,areas);
            }
            
        }
        
        else if(admin_option==4){
            int valreturn = adminoption4 (); //input from more data menu
            switch(valreturn){
                case 1: data_option1(areas); break;
                case 2: data_option2(); break;
                case 3: data_option3(); break; 
                case 4: data_option4(areas); break;
                default: ;
            }

        }
    }
    
    else if(login_input=='M' || login_input=='m'){
        system("CLS");
        int ms_option = ms_options(); //input from Medical Specialist menu
        system("CLS");
        
        if(ms_option==1){
            ms_options1();
        }
        
        else if(ms_option==2){
            ms_options2(areas,march_stats,april_stats);
        }
        
        else if(ms_option==3){
            ms_options3();
        }
        
        else if(ms_option==4){
            int option3;
            option3 = adminoption3(); //input from reports menu
            
            if(option3==1){ 
                report_option1(march_stats,april_stats,areas);
            }
            
            else if(option3==2){
                report_option2(march_stats,april_stats);
            }
            
            else if(option3==3){
                report_option3(march_stats,april_stats);
            }
            
            else if(option3==4){
                report_option4();
            }
            
            else if(option3==5){
                report_option5();
            }
            
            else if(option3==6){
                report_option6();
            }
            
            else if(option3==7){
                report_option7();
            }
            
            else if(option3==8){
                report_option8(areas);
            }
            
            else if(option3==9){
                report_option9(areas);
            }
            
            else if(option3==10){
                report_option10(march_stats,areas);
            }
            
            else if(option3==11){
                report_option11(march_stats,april_stats);
            }
            
            else if(option3==12){
                report_option12(march_stats,april_stats);
            }
            
            else if(option3==13){
                report_option13(march_stats,april_stats,areas);
            }
            
            else if(option3==14){
                report_option14(march_stats,areas);
            }
            
        }
        
    }
    
    else if(login_input=='C' || login_input=='c'){
        int cz = citizen_options(); // input from citizen user menu
        if(cz==1){
            system("CLS");
            int option3; 
            option3 = adminoption3(); //input from reports menu
            
            if(option3==1){ 
                report_option1(march_stats,april_stats,areas);
            }
            
            else if(option3==2){
                report_option2(march_stats,april_stats);
            }
            
            else if(option3==3){
                report_option3(march_stats,april_stats);
            }
            
            else if(option3==4){
                report_option4();
            }
            
            else if(option3==5){
                report_option5();
            }
            
            else if(option3==6){
                report_option6();
            }
            
            else if(option3==7){
                report_option7();
            }
            
            else if(option3==8){
                report_option8(areas);
            }
            
            else if(option3==9){
                report_option9(areas);
            }
            
            else if(option3==10){
                report_option10(march_stats,areas);
            }
            
            else if(option3==11){
                report_option11(march_stats,april_stats);
            }
            
            else if(option3==12){
                report_option12(march_stats,april_stats);
            }
            
            else if(option3==13){
                report_option13(march_stats,april_stats,areas);
            }
            
            else if(option3==14){
                report_option14(march_stats,areas);
            }
        }
        
        else if(cz==2){
            citizen_options2(areas,march_stats,april_stats);
        }
        
        else{
            citizen_options3(areas,march_stats,april_stats);
        }
    }
    
    return 0;
}

void name(){
    cout<<"\t\t\t\t **** COVID-19 STATISTICS **** "<<endl;
} //Program name

char login_main(){
    char login_input;
    cout<<"User login: "<<endl;
    cout<<"- Admin User (input A) \n- Medical Specialist as user (input M) \n- Citizen of Pakistan (input C)"<<endl;
    cout<<"Input: ";
    cin>>login_input;
    while(login_input != 'A' && login_input != 'a' && login_input != 'M' && login_input != 'm' && login_input != 'C' && login_input != 'c'){
            cout<<"Invalid input... re-input: ";
            cin>>login_input;
    }
    return login_input;   
} //Main menu

void adminpassvalidate(){
    string admin_pass;
    cout<<"\t\t\t\t** Admin Panel **"<<endl;
    cout<<"Input password: ";
    cin>>admin_pass;
    while(admin_pass!="moaz"){
        cout<<"Invalid password...re-input: ";
        cin>>admin_pass;
    }
} //Pass validate for admin function

int admin_options(){
    int admin_option;
    cout<<"\t\t Welcome to the ADMIN panel"<<endl;
    cout<<"Options :- \n1. Add tests conducted in current month \n2. Enter the additional cases of covid-19 in a particular area \n3. Reports \n4. Check current stats"<<endl;
    cout<<"Please input here (1-4): ";
    cin>>admin_option; 
    while(admin_option != 1 && admin_option != 2 && admin_option != 3 && admin_option != 4){
        cout<<"Invalid password...re-input: ";
        cin>>admin_option; 
    }
    return admin_option;
} //admin menu

void adminoption1 (){
    int testsconducted;
    int total_tests;
    ifstream Inputfile;
    Inputfile.open("total_tests.txt");
    Inputfile>>total_tests;  
    Inputfile.close();

    cout<<"Number of total tests conducted: "<<total_tests<<endl;
    cout<<"Add additional number tests conducted in current month: ";
    cin>> testsconducted;
    while(!(testsconducted>=0)){
        cout<<"Invalid input... re-input: ";
        cin>>testsconducted;
    }
    total_tests = total_tests + testsconducted;
    cout<<"Updated... Number of total tests conducted: "<<total_tests<<endl;
    
    ofstream outfile; 
    outfile.open("total_tests.txt");
    outfile<<total_tests<<endl;
    outfile.close();   
    
    
} //add tests conducted in current month

void adminoption2 (string areas[7]){
    string area;
    int additionalcases;
    int temparray[8]; //to store updated may stats
    int temparrayy2[7]; //updated total cases areawise stats
    int temparraayy2[7]; //New Cases Areawise for May modification

    cout<<"Enter the additional cases of covid-19 in a particular area!"<<endl;
    cout<<"AREAS: "<<endl;
    for(int j=0;j<7;j++){
        cout<<"\t"<<areas[j]<<endl;
    }
    cout<<endl;
    cout<<"Input area (in lowercase): ";
    cin>>area;
    while(area != "sindh" && area !="punjab" && area != "kpk" && area != "balochistan" && area != "islamabad" && area != "gilgit" && area != "kashmir"){
        cout<<"Invalid input... re-input: ";
        cin>>area;
    }
    cout<<"Input additional cases: ";
    cin>>additionalcases;
    while(!(additionalcases>=0)){
        cout<<"Invalid input.. re-input: ";
        cin>>additionalcases;
    }
    
    
    
    //May stats modification
    ifstream Inputfile;
    Inputfile.open("may_stats.txt");
    for(int i=0;i<8;i++){
        Inputfile>>temparray[i];
    }
    Inputfile.close();
   
    ofstream outfile; 
    outfile.open("may_stats.txt");
    for(int j=0;j<7;j++){
        if(area==areas[j]){
            temparray[j]=temparray[j]+additionalcases;
            outfile<<temparray[j]<<endl;
            cout<<"Data updated....\n";
            cout<<"Number of cases for month of May in "<<area<<": "<<temparray[j]<<endl;
        }
        else{
            outfile<<temparray[j]<<endl;
        }

    }
    outfile<<temparray[7]<<endl;

    outfile.close();
    
    //Total Cases modification
    int total_cases;
    ifstream Inputfilee;
    Inputfilee.open("total_cases.txt");
    Inputfilee>>total_cases;
    Inputfilee.close();
    
    ofstream outfilee; 
    outfilee.open("total_cases.txt");
    total_cases=total_cases+additionalcases;
    outfilee<<total_cases<<endl;
    cout<<"Total cases in the country: "<<total_cases<<endl;
    outfilee.close();
    
  
  
    //Total Cases Areawise modification
    ifstream inputt;
    inputt.open("total_cases_areawise.txt");
    for(int k=0;k<7;k++){
        inputt>>temparrayy2[k];
    }
    inputt.close();
    
    ofstream writefile; 
    writefile.open("total_cases_areawise.txt");
    for(int k=0;k<7;k++){
        if(area==areas[k]){
            temparrayy2[k]=temparrayy2[k]+additionalcases;
            writefile<<temparrayy2[k]<<endl;
            cout<<"Total Number of cases for area of "<<area<<" upto date: "<<temparrayy2[k]<<endl;
        }
        else{
            writefile<<temparrayy2[k]<<endl;
        }
        
    }
    writefile.close();
    
    //New Cases Areawise for May modification
    ifstream inpuutt;
    inpuutt.open("new_cases_areawise_may.txt");
    for(int k=0;k<7;k++){
        inpuutt>>temparraayy2[k];
    }
    inpuutt.close();
    
    ofstream writefilee; 
    writefilee.open("new_cases_areawise_may.txt");
    for(int k=0;k<7;k++){
        if(area==areas[k]){
            temparraayy2[k]=temparraayy2[k]+additionalcases;
            writefilee<<temparraayy2[k]<<endl;
        }
        else{
            writefilee<<temparraayy2[k]<<endl;
        }
        
    }
    writefilee.close();
    
} //enter the additional cases of covid-19 in a particular area

int adminoption3 (){
    int num;
    cout<<"\t\t\t** REPORTS **" <<endl;
    cout<<endl;
    
    cout<<"No.\t\t Report Options" <<endl;
    cout<<" 1. Percentage increase in corona spread in an area (month wise)"<<endl;
    cout<<" 2. Percentage increase in deaths (between any 2 months)"<<endl;
    cout<<" 3. Percentage increase in confirmed cases in country (between any two months)"<<endl;
    cout<<" 4. Total number of recovered patients"<<endl;
    cout<<" 5. Total number of tests conducted"<<endl;
    cout<<" 6. Total number of deaths"<<endl;
    cout<<" 7. Death rate (calculated from total cases and total deaths in the country)"<<endl;
    cout<<" 8. Area with the highest number of cases (at the moment)"<<endl;
    cout<<" 9. Area with the minimum number of cases (at the moment)"<<endl;
    cout<<"10. Area with the highest rate of spread" <<endl;
    cout<<"11. Month with the highest number of deaths"<<endl;
    cout<<"12. Average number of cases in any month (avg. of all areas)"<<endl;
    cout<<"13. Average spread in an area over the three months"<<endl;
    cout<<"14. Area with the highest percentage increase (comparing Mar & May)"<<endl;
    
    cout<<endl;
    cout<<"Input the number of the report you want to view: ";
    cin>>num;
    while(!(num>0 && num<=14)){
        cout<<"Invalid number...re-input: ";
        cin>>num; 
    }
    return num;
} //Reports menu 

int adminoption4 (){
    system("CLS");
    int num;
    cout<<"\t\t\t** More Data **"<<endl;
    cout<<"1. Total number of confirmed cases in an area"<<endl;
    cout<<"2. Total number of cases in country"<<endl;
    cout<<"3. Total number of deaths in country"<<endl;
    cout<<"4. Number of new cases in any area (for May)"<<endl;
    cout<<"Input the number of the data you want to view: ";
    cin>>num;
    while(!(num>0 && num<=4)){
        cout<<"Invalid number...re-input: ";
        cin>>num; 
    }
    return num;
} //More Data menu

void data_option1(string areas[]){
    system("CLS");
    string area;
    cout<<"\t* Total number of confirmed cases in an area *"<<endl;
    cout<<"AREAS: "<<endl;
    for(int j=0;j<7;j++){
        cout<<"\t"<<areas[j]<<endl;
    }
    cout<<"Input area (in lowercase): ";
    cin>>area;
    while(area != "sindh" && area !="punjab" && area != "kpk" && area != "balochistan" && area != "islamabad" && area != "gilgit" && area != "kashmir"){
        cout<<"Invalid input... re-input: ";
        cin>>area;
    }
    
    ifstream area_cases;
    int area_case[7];
    int casee;
    area_cases.open("total_cases_areawise.txt");
    for(int i=0;i<7;i++){
        area_cases>>casee;
        area_case[i]=casee;
    }
    area_cases.close();
    int position;
    for(int j=0;j<7;j++){
        if(area==areas[j]){
            position=j;
        }
    }
    cout<<"Total number of confirmed cases in "<<area<<": "<<area_case[position]<<endl;
} //Total number of confirmed cases in an area

void data_option2(){
        system("CLS");
        int numm;
        cout<<"\t\t\t ** Total Cases **"<<endl;
        ifstream inputt;
        inputt.open("total_cases.txt");
        inputt>>numm;
        inputt.close();
        cout<<"Total number of cases in country: "<<numm<<endl;

} //Total number of cases in country
 
void data_option3(){
        system("CLS");
        int numm;
        cout<<"\t\t\t ** Total Deaths **"<<endl;
        ifstream inputt;
        inputt.open("total_deaths.txt");
        inputt>>numm;
        inputt.close();
        cout<<"Total number of deaths in country: "<<numm<<endl;    
} //Total number of deaths in country

void data_option4(string areas[]){
    system("CLS");
    string area;
    cout<<"\t* Total number of new cases in any area (for May) *"<<endl;
    cout<<"AREAS: "<<endl;
    for(int j=0;j<7;j++){
        cout<<"\t"<<areas[j]<<endl;
    }
    cout<<"Input area (in lowercase): ";
    cin>>area;
    while(area != "sindh" && area !="punjab" && area != "kpk" && area != "balochistan" && area != "islamabad" && area != "gilgit" && area != "kashmir"){
        cout<<"Invalid input... re-input: ";
        cin>>area;
    }
    
    ifstream area_cases;
    int area_case[7];
    int casee;
    area_cases.open("new_cases_areawise_may.txt");
    for(int i=0;i<7;i++){
        area_cases>>casee;
        area_case[i]=casee;
    }
    area_cases.close();
    int position;
    for(int j=0;j<7;j++){
        if(area==areas[j]){
            position=j;
        }
    }
    cout<<"Total number of new cases in "<<area<<"(after may 15): "<<area_case[position]<<endl; 
} //Number of new cases in any area (for May)

void report_option1(float march_stats[], float april_stats[], string areas[]){
    system("CLS");
    cout<<"\t* Percentage increase in corona spread in an area (month wise) Report *\n"<<endl;
    cout<<"AREAS:-  "<<endl;
    for(int z=0;z<7;z++){
        cout<<"\t"<<areas[z]<<endl;
    }
    ifstream inputfile;
    float value;
    float temporaryarray[7]; //to store may stats
    
    //Reading may stats in temporaryarray[7]
    inputfile.open("may_stats.txt");
    for(int i=0;i<7;i++){
        inputfile>>value;
        temporaryarray[i]=value;
    }
    inputfile.close();
    
    float percinc_1_2[7]; //Percentage icrease between march & april
    float percinc_2_3[7]; //Percentage icrease between april & may  
    
    for(int j=0;j<7;j++){
        percinc_1_2[j] = ((april_stats[j])/march_stats[j])*100;
        percinc_2_3[j] = ((temporaryarray[j])/(april_stats[j]+march_stats[j]))*100; 
    }
    
    //INPUT with Validation
    string area;
    cout<<"Input area (in lowercase) you want the data for: ";
    cin>>area;
    bool found=false;
    for(int a=0;a<7;a++){
        if(area==areas[a]){
            found=true;
        }   
    }
    while(found==false){
        cout<<"Invalid input... re-input area (make sure it is in lowercase): ";
        cin>>area;
        for(int a=0;a<7;a++){
            if(area==areas[a]){
                found=true;
            }   
        }
    }
    
    for(int k=0;k<7;k++){
        if(area==areas[k]){
            cout<<"March-April: "<<percinc_1_2[k]<<"%"<<endl;
            cout<<"April-May: "<<percinc_2_3[k]<<"%"<<endl;
        }
    }
    
} //Percentage increase in corona spread in an area(month wise)

void report_option2(float march_stats[], float april_stats[]){
    system("CLS");
    string m1,m2;
    cout<<"\t\t * Deaths Report *"<<endl;
    
    cout<<"Enter first month (march/april) in lowercase only: ";
    cin>>m1;
    while(m1!="march" && m1!="april" && m1!="may"){
        cout<<"Invalid month...Please re-input (in lowercase only): ";
        cin>>m1;
    }
    
    cout<<"Enter second month (march/april/may) in lowercase only: ";
    cin>>m2;
    while(m2!="march" && m2!="april" && m2!="may"){
        cout<<"Invalid month...Please re-input (in lowercase only): ";
        cin>>m2;
    }
    
    int may_stat;
    ifstream Inputfile;
    Inputfile.open("may_stats.txt");
    for(int i=1;i<=8;i++){
        Inputfile>> may_stat;
    }
    Inputfile.close();
    
    if(m1=="march" && m2=="april"){
        cout<<"Deaths in march: "<< march_stats[7]<<endl;
        cout<<"Deaths in april: "<< april_stats[7]<<endl;
        float diff = april_stats[7] - march_stats[7];
        float perc_inc = (diff/march_stats[7])*100;
        cout<<"Percentage increase: "<<perc_inc<<"%"<<endl;
    }
    
    else if(m1=="april" && m2=="may"){
        cout<<"Deaths in april: "<< april_stats[7]<<endl;
        int may_stat;
        
        cout<<"Deaths in may: "<< may_stat<<endl;
        
        float diff = may_stat - april_stats[7];
        float perc_inc = (diff/april_stats[7])*100;
        cout<<"Percentage increase: "<<perc_inc<<"%"<<endl;
    }
    else if(m1=="march" && m2=="may"){
        cout<<"Deaths in march: "<< march_stats[7]<<endl;
        int may_stat;
        // ifstream Inputfile;
        // Inputfile.open("may_stats.txt");
        // for(int i=1;i<=8;i++){
        // Inputfile>> may_stat;
        // }
        cout<<"Deaths in may: "<< may_stat<<endl;
        // Inputfile.close();
        
        float diff = may_stat - march_stats[7];
        float perc_inc = (diff/march_stats[7])*100;
        cout<<"Percentage increase: "<<perc_inc<<"%"<<endl;
    }

}  //Percentage increase in deaths (between any 2 months)

void report_option3(float march_stats[], float april_stats[]){
    system("CLS");
    string m1,m2;
    int sum1=0,sum2=0,sum3=0;
    cout<<"\t\t * Confirmed Cases Report *"<<endl;
    cout<<"Enter first month (march/april) in lowercase only: ";
    cin>>m1;
    while(m1!="march" && m1!="april" && m1!="may"){
        cout<<"Invalid month...Please re-input (in lowercase only): ";
        cin>>m1;
    }
    cout<<"Enter second month (march/april/may) in lowercase only: ";
    cin>>m2;
    while(m2!="march" && m2!="april" && m2!="may"){
        cout<<"Invalid month...Please re-input (in lowercase only): ";
        cin>>m2;
    }
    
    for(int i=0;i<7;i++){
        sum1=sum1+march_stats[i]; //sum of march stats (all areas)
        sum2=sum2+april_stats[i]; //sum of april stats (all areas)
    }
    
    int num=0;
    ifstream Inputfile;
    Inputfile.open("may_stats.txt");
    for(int i=1;i<=7;i++){
        Inputfile>> num;
        sum3=sum3+num;            //sum of may stats (all areas)
    }
    Inputfile.close();
    
    if(m1=="march" && m2=="april"){
        cout<<"Confirmed Cases in March: "<< sum1<<endl;
        cout<<"Confirmed Cases in April: "<< sum2<<endl;
        
        float diff = sum2 - sum1;
        float perc_inc = (diff/sum1)*100;
        cout<<"Percentage increase: "<<perc_inc<<"%"<<endl;
    }
    else if(m1=="april" && m2=="may"){
        cout<<"Confirmed Cases in April: "<< sum2<<endl;
        cout<<"Confirmed Cases in May: "<< sum3<<endl;

        float diff = sum3 - sum2;
        float perc_inc = (diff/sum2)*100;
        cout<<"Percentage increase: "<<perc_inc<<"%"<<endl;
    }
    else if(m1=="march" && m2=="may"){
        cout<<"Confirmed Cases in March: "<< sum1<<endl;
        cout<<"Confirmed Cases in May: "<< sum3<<endl;       
        
        float diff = sum3 - sum1;
        float perc_inc = (diff/sum1)*100;
        cout<<"Percentage increase: "<<perc_inc<<"%"<<endl;
    }

    
} //Percentage increase in confirmed cases in country (between any two month)

void report_option4(){
    system("CLS");
    cout<<"\t\t * Recovered Patients Report *"<<endl;
    ifstream inputfile;
    inputfile.open("recovered.txt");
    int num;
    inputfile>>num;
    inputfile.close();
    cout<<"Total number of recovered Patients: "<<num<<endl;
    
} //Total number of recovered patients

void report_option5(){
    system("CLS");
    cout<<"\t\t * Total Tests Report *"<<endl;
    ifstream inputfile;
    inputfile.open("total_tests.txt");
    int num;
    inputfile>>num;
    inputfile.close();
    cout<<"Total number of tests conducted: "<<num<<endl;
    
} //Total number of tests conducted

void report_option6(){
    system("CLS");
    cout<<"\t\t * Total Deaths Report *"<<endl;
    ifstream inputfile;
    inputfile.open("total_deaths.txt");
    int num;
    inputfile>>num;
    inputfile.close();
    cout<<"Total number of deaths: "<<num<<endl;
    
} //Total number of deaths

void report_option7(){
    system("CLS");
    cout<<"\t\t * Death Rate Report *"<<endl;
    ifstream inputfile;
    inputfile.open("total_cases.txt");
    float cases;
    inputfile>>cases;
    inputfile.close();
    
    ifstream inputfile2;
    inputfile2.open("total_deaths.txt");
    float deaths;
    inputfile2>>deaths;
    inputfile2.close();
    
    float dr = deaths/cases;
    cout<<"Death rate: "<<dr<<endl;
} //Death rate

void report_option8(string areas[]){
    system("CLS");
    int max=0,num,maxvalposition;
    cout<<"\t * Highest Number of Cases Report *"<<endl;
    ifstream inputfile;
    inputfile.open("total_cases_areawise.txt");
    for(int i=0;i<7;i++){
        inputfile>>num;
        if(num>max){
            max=num;
            maxvalposition=i;
        }
    }
    cout<<"Area with highest number of cases: "<<areas[maxvalposition]<<endl;
    cout<<"Number of cases in the area ("<<areas[maxvalposition]<<"): "<<max<<endl;
    inputfile.close();
} //Area with the highest number of cases

void report_option9(string areas[]){
    system("CLS");
    int min=999999,num,minvalposition;
    cout<<"\t * Least Number of Cases Report *"<<endl;
    ifstream inputfile;
    inputfile.open("total_cases_areawise.txt");
    for(int i=0;i<7;i++){
        inputfile>>num;
        if(num<min){
            min=num;
            minvalposition=i;
        }
    }
    cout<<"Area with lowest number of cases: "<<areas[minvalposition]<<endl;
    cout<<"Number of cases in the area ("<<areas[minvalposition]<<"): "<<min<<endl;
    inputfile.close();
} //Area with the minimum number of cases

void report_option10(float march_stats[],string areas[]){
    system("CLS");
    cout<<"\t* Highest rate of spread report*"<<endl;
    ifstream input1;
    float calculation;
    float Value;
    float temp[7];
    input1.open("total_cases_areawise.txt");
    for(int i=0;i<7;i++){
        input1>>Value;
        calculation=((Value-march_stats[i])/march_stats[i]);
        temp[i]=calculation;
    }
    input1.close();
    float max=0;
    int position;
    for(int j=0;j<7;j++){
        if(temp[j]>max){
            max=temp[j];
            position=j;
        }
    }
    cout<<"Area with the highest rate of spread: "<<areas[position]<<" which is "<<max<<endl;
} //Area with the highest rate of spread

void report_option11(float march_stats[],float april_stats[]){
    system("CLS");
    int a,num;
    cout<<"\t * Highest number of deaths Report *"<<endl;
    ifstream inputfile;
    inputfile.open("may_stats.txt");
    for(int i=0;i<8;i++){
        inputfile>>num;
        a=num;
    }
    inputfile.close();
    int b = march_stats[7];
    int c = april_stats[7];
    if(a>b && a>c){
        cout<<"Month with highest number of deaths: May which is equal to "<<a<<endl;
    }
    else if(b>a && b>c){
        cout<<"Month with highest number of deaths: March which is equal to "<<b<<endl;
    }
    else if(c>a && c>b){
        cout<<"Month with highest number of deaths: April which is equal to "<<c<<endl;
    }
    else{
        cout<<"Two of the months had same number of deaths (highest).."<<endl;
    }
} //Month with the highest number of deaths

void report_option12(float march_stats[],float april_stats[]){
    system("CLS");
    cout<<"\t * Average number of cases in any month Report *"<<endl;
    ifstream inputfile;
    inputfile.open("may_stats.txt");
    float num,sum=0,sum2=0,sum3=0;
    for(int i=0;i<7;i++){
        inputfile>>num;
        sum=sum+num;
        sum2=sum2+march_stats[i];
        sum3=sum3+april_stats[i];
    }
    float avg1 = sum/7;    //may stats avg
    float avg2 = sum2/7;   //march stats avg
    float avg3 = sum3/7;   //april stats avg
    inputfile.close();
    string month;
    cout<<"Input month in lower case (march/april/may) to find average number of cases in any month (of all areas): ";
    cin>>month;
    while(month!="march" && month!="april" && month!="may"){
        cout<<"Invalid month...Please re-input (in lowercase only): ";
        cin>>month;
    }
    if(month=="march"){
        cout<<"Average number of cases (avg. of all areas) for the month of "<<month<<": "<<avg2<<endl;
    }
    else if(month=="april"){
        cout<<"Average number of cases (avg. of all areas) for the month of "<<month<<": "<<avg3<<endl;
        
    }
    else{
        cout<<"Average number of cases (avg. of all areas) for the month of "<<month<<": "<<avg1<<endl;
    }
    
} //Average number of cases in any month

void report_option13(float march_stats[], float april_stats[],string areas[]){
    system("CLS");
    ifstream input;
    int may_stats[7];
    int num;
    input.open("may_stats.txt");
    for(int i=0;i<7;i++){
        input>>num;
        may_stats[i]=num;
    }
    input.close();
    int position;
    string area;
    cout<<"\t * Average spread over the three months Report *"<<endl;
    cout<<"Input area (in lowercase) you want the report for: ";
    cin>>area;
    bool found=false;
    for(int a=0;a<7;a++){
        if(area==areas[a]){
            found=true;
            position=a;
        }   
    }
    while(found==false){
        cout<<"Invalid input... re-input area (make sure it is in lowercase): ";
        cin>>area;
        for(int a=0;a<7;a++){
            if(area==areas[a]){
                found=true;
                position=a;
            }   
        }
    }
    float avg=(march_stats[position]+april_stats[position]+may_stats[position])/3;
    cout<<"Average spread in "<<areas[position]<<" over the three months: "<<avg<<endl;

} //Average spread in an area over the three months

void report_option14(float march_stats[],string areas[]){
    ifstream inputfile;
    float num;
    float temparray[7]; //may stats temporary array
    float max=0;
    float maxperinc;    
    int maxperincposition;
    inputfile.open("may_stats.txt");
    for(int i=0;i<7;i++){
        inputfile>>num;
        temparray[i]=num;
    }
    inputfile.close(); 
    for(int j=0;j<7;j++){
        maxperinc=((temparray[j]-march_stats[j])/march_stats[j])*100;
        if(maxperinc>max){
            max=maxperinc;
            maxperincposition=j;
        }
    }
    cout<<"Area with the highest percentage increase (comparing Mar & May): "<<areas[maxperincposition]<<endl;
    cout<<"Highest percentage increase for the following area is: "<<max<<"%"<<endl;
} //Area with the highest percentage increase (comparing Mar & May)

int ms_options(){
    int ms_option;
    cout<<"\t\t Welcome to the Medical Specialist Panel"<<endl;
    cout<<"Options :- \n1. Enter number of new deaths \n2. Enter number of new cases (area wise positive cases) \n3. Enter number of new recovered patients in country \n4. Reports"<<endl;
    cout<<"Please input here (1-4): ";
    cin>>ms_option; 
    while(ms_option != 1 && ms_option != 2 && ms_option != 3 && ms_option != 4){
        cout<<"Invalid input...re-input: ";
        cin>>ms_option; 
    }
    return ms_option;    
} //Medical Specialist menu

void ms_options1(){
    int moredeaths,num,num2;
    int total_deaths=0;
    ifstream inputfile;
    inputfile.open("total_deaths.txt");
    inputfile>>num;
    cout<<"Total number of deaths uptil now: "<<num<<endl;
    cout<<"Input additional deaths: ";
    cin>>moredeaths;
    total_deaths=num+moredeaths;
    inputfile.close();
    
    //UPDATING TOTAL DEATHS IN TOTAL CASES AREAWISE FILE since deaths picked and used in some functions
    int vall;    
    int newarray[8];
    ifstream neew;
    neew.open("total_cases_areawise.txt");
    for(int q=0;q<8;q++){
        neew>>vall;
        newarray[q]=vall;
    }
    newarray[7]=newarray[7]+moredeaths;
    neew.close();

    
    
    ofstream outfile;
    outfile.open("total_deaths.txt");
    outfile<<total_deaths<<endl;
    outfile.close();
    cout<<"Update done...."<<endl;
    cout<<"Updated total number of deaths: "<<total_deaths<<endl;
    
    int temparrayy[8];  //for may stats deaths modification
    
    ifstream inputfile2;
    inputfile2.open("may_stats.txt");
    for(int i=0;i<8;i++){
        inputfile2>>num2;
        temparrayy[i]=num2;
    }
    temparrayy[7]=temparrayy[7]+moredeaths;
    inputfile.close();
    
    ofstream outfile2;
    outfile2.open("may_stats.txt");
    for(int j=0;j<8;j++){
        outfile2<<temparrayy[j]<<endl;
        
    }
    outfile.close();
    

    ofstream neww;
    neww.open("total_cases_areawise.txt");
    for(int l=0;l<8;l++){
        neww<<newarray[l]<<endl;  //modified data being written onto newarray (the total deaths at position 7)
    }
    neww.close();
    
} //enter number of new deaths

void ms_options2(string areas[],float march_stats[],float april_stats[]){
    system("CLS");
    int temparrayy[8]; //new cases areawise for may temporary array
    int num;
    
    ifstream inputfile;
    inputfile.open("new_cases_areawise_may.txt");
    for(int j=0;j<8;j++){
        inputfile>>num;
        temparrayy[j]=num;
    }
    inputfile.close(); 
    
    //MAKING ALL FILES GO BACK TO INITIAL VALUES BEFORE VALUE OF NEW CASES AREAWISE FOR MAY GETS UPDATED!!!
    int tempareawise[8]; 
    ifstream areawise;
    int valuee;
    areawise.open("total_cases_areawise.txt");
    for(int p=0;p<8;p++){
        areawise>>valuee;
        tempareawise[p]=valuee;
        tempareawise[p]=tempareawise[p]-temparrayy[p];
    }
    areawise.close();
    
    ifstream may_stats;
    int inputt;
    int tempmaystats[8]; //may stats temporary array
    may_stats.open("may_stats.txt");
    for(int i=0;i<8;i++){
        may_stats>>inputt;
        tempmaystats[i]=inputt;
        tempmaystats[i]=tempmaystats[i]-temparrayy[i];
    }
    may_stats.close();
    
    
    
    char decision='y';
    cout<<"Enter number of new cases (area wise positive cases):-"<<endl;
    cout<<"No.\t* Areas *"<<endl;
    for(int i=0;i<7;i++){
        cout<<i+1<<"\t"<<areas[i]<<endl;
    }
    
    int no,cases;
    while(decision=='y'||decision=='Y'){
        cout<<"Enter no. of area with new positive cases: ";
        cin>>no;
        while(!(no>0 && no<8)){
            cout<<"Invalid input... please re-enter the following:-"<<endl;
            cout<<"Enter no. of area with new positive cases: ";
            cin>>no;
        }
        
        cout<<"Enter number of the new positive cases for the following area: ";
        cin>>cases;
        while(!(cases>=0)){
            cout<<"Invalid input... please re-enter the following:-"<<endl;
        cout<<"Enter number of the new positive cases for the following area: ";
            cin>>cases;
        }
        
        temparrayy[no-1]=temparrayy[no-1]+cases; //cases values being saved in temporary array for new cases areawise for may
        
        cout<<"Enter cases for a different area (y/n): ";
        cin>>decision;
        while(decision!='y' && decision!='Y' && decision!='n' && decision!='N'){
            cout<<"Invalid input....please re-input: ";
            cin>>decision;
        }
    }
    
    ofstream outfile;
    cout<<endl;
    cout<<"Update done..."<<endl;

    outfile.open("new_cases_areawise_may.txt");
    cout<<"*Areas*\t\t*New Positive Cases (In May)*"<<endl;    
    for(int k=0;k<8;k++){
        outfile<<temparrayy[k]<<endl;
        if(k==7){
            
            //just to make sure it gets written on the new cases areawise file for may or else would have to create another for loop
        }
        else if(k==3){
            cout<<areas[k]<<"     \t\t"<<temparrayy[k]<<endl;
        }
        else if(k==4){
            cout<<areas[k]<<"       \t\t"<<temparrayy[k]<<endl;
        }
        else{
            cout<<areas[k]<<"\t\t\t\t"<<temparrayy[k]<<endl;

        }
    }
    outfile.close();

    
    for(int a=0;a<8;a++){
        tempmaystats[a]=tempmaystats[a]+temparrayy[a]; //may stats modified with newcases data added
    }
    
    ofstream may_stats_write;
    may_stats_write.open("may_stats.txt");
    for(int i=0;i<8;i++){
        may_stats_write<<tempmaystats[i]<<endl;
    }
    may_stats_write.close();
    
    int total=0;
    for(int z=0;z<7;z++){
        total=total+march_stats[z]+april_stats[z]+tempmaystats[z]; //total stats modified to be written to total cases txt file (for all areas)
    }
    
    ofstream totalwrite;
    totalwrite.open("total_cases.txt");
    totalwrite<<total<<endl;
    totalwrite.close();
    
    
    for(int i=0;i<8;i++){
        tempareawise[i]=tempareawise[i]+temparrayy[i]; //total areawise cased modified to be written to total_cases_areawise.txt 
    }
    
    ofstream writeit;
    writeit.open("total_cases_areawise.txt");
    for(int j=0;j<8;j++){
        writeit<<tempareawise[j]<<endl;
    }
    writeit.close();
    
} //enter number of new cases (area wise positive cases)

void ms_options3(){
    ifstream inputfile;
    int morerecovered,total_recovered=0,num;
    inputfile.open("recovered.txt");
    inputfile>>num;
    cout<<"Total number of recovered uptil now: "<<num<<endl;
    cout<<"Input additional recovered patients: ";
    cin>>morerecovered;
    total_recovered=num+morerecovered;
    inputfile.close();
    ofstream outfile;
    outfile.open("recovered.txt");
    outfile<<total_recovered<<endl;
    outfile.close();
    cout<<"Update done...."<<endl;
    cout<<"Updated total number of recovered patients: "<<total_recovered<<endl;
        
} //enter number of new recovered patients in country

int citizen_options(){
    system("CLS");
    cout<<"\t\t Welcome to the Citizen of Pakistan User Panel"<<endl;
    int cz_option;
    cout<<"1. View Reports"<<endl;
    cout<<"2. Areawise Reports" <<endl; 
    cout<<"3. General Pakistan's Data"<<endl;
    cout<<"Please input here (1-3): ";
    cin>>cz_option; 
    while(cz_option != 1 && cz_option != 2 && cz_option != 3){
        cout<<"Invalid input...re-input: ";
        cin>>cz_option; 
    }
    return cz_option;
    
} //citizen user menu

void citizen_options2(string areas[],float march_stats[],float april_stats[]){
    system("CLS");
    int no;
    cout<<"\t\t\t* Reports for any particular area *"<<endl;
    cout<<"No.\t* Areas *"<<endl;
    for(int i=0;i<7;i++){
        cout<<i+1<<"\t"<<areas[i]<<endl;
    }
    cout<<"Enter no. of area you want reports for: ";
    cin>>no;
    while(!(no>0 && no<8)){
        cout<<"Invalid input... please re-input: "<<endl;
        cin>>no;
    }
    int value,valuee,valueee;
    int temp1[7]; //temporary array for may stats
    int temp2[7]; //temporary array for total cases areawise stats
    int temp3[7]; //temporary array for new cases areawise stats
    ifstream inputt;
    inputt.open("may_stats.txt");
    for(int i=0;i<8;i++){
        inputt>>value;
        temp1[i]=value;
    }
    inputt.close();
    ifstream inputtt;
    inputtt.open("total_cases_areawise.txt");
    for(int j=0;j<8;j++){
        inputtt>>valuee;
        temp2[j]=valuee;
    }
    inputtt.close();
    ifstream inputttt;
    inputttt.open("new_cases_areawise_may.txt");
    for(int k=0;k<8;k++){
        inputttt>>valueee;
        temp3[k]=valueee;
    }
    inputttt.close();
    
    for(int i=0;i<8;i++){
        if((no-1)==i){
            cout<<"Area you chose: "<<areas[i]<<endl;
            cout<<"Number of cases in the month of March: "<<march_stats[i]<<endl;
            cout<<"Number of cases in the month of April: "<<april_stats[i]<<endl;
            cout<<"Number of cases in the month of May (upto may 15): "<<temp1[i]-temp3[i]<<endl;
            cout<<"Number of additional cases in the month of May (after may 15): "<<temp3[i]<<endl;
            cout<<"Total Number of cases in the month of May: "<<temp1[i]<<endl;
            cout<<"Total number of cases in "<<areas[i]<<": "<<temp2[i]<<endl;
            cout<<endl;
        }
    }
    
    
    
    
    
} //reports for any particular area

void citizen_options3(string areas[],float march_stats[],float april_stats[]){
    system("CLS");
    int no;
    int temp1[7]; // may stats array
    int temp2[7]; //total cases areawise array
    int temp3[7]; // new cases areawise for may array
    int value;
    cout<<"\t* General report for Pakistan (Covid-19 stats) *"<<endl;
    ifstream input1;
    input1.open("may_stats.txt");
    for(int i=0;i<8;i++){
        input1>>value;
        temp1[i]=value;
    }
    input1.close();
    int valuee;
    ifstream input2;
    input2.open("total_cases_areawise.txt");
    for(int j=0;j<8;j++){
        input2>>valuee;
        temp2[j]=valuee;
    }
    input2.close();
    int valueee;
    ifstream input3;
    input3.open("new_cases_areawise_may.txt");
    for(int k=0;k<8;k++){
        input3>>valueee;
        temp3[k]=valueee;
    }
    input3.close();

    int recovered,valueeee;
    ifstream input4;
    input4.open("recovered.txt");
        input4>>valueeee;
        recovered=valueeee;
    input4.close();
    
    int totaltestss,valueeeee;
    ifstream input5;
    input5.open("total_tests.txt");
        input5>>valueeeee;
        totaltestss=valueeeee;
    input5.close();
    
    int totalcasess,valueeeeee;
    ifstream input6;
    input6.open("total_cases.txt");
        input6>>valueeeeee;
        totalcasess=valueeeeee;
    input6.close();
    
    cout<<"Number of total tests in Pakistan: "<<totaltestss<<endl;
    cout<<"Number of total cases in Pakistan: "<<totalcasess<<endl;
    cout<<"Number of people recovered: "<<recovered<<endl;
    cout<<"Number of deaths in the month of March: "<<march_stats[7]<<endl;
    cout<<"Number of deaths in the month of April: "<<april_stats[7]<<endl;
    cout<<"Number of deaths in the month of May: "<<temp1[7]<<endl;
    cout<<"Total number of deaths: "<<temp2[7]<<endl;
} //all reports for Pakistan






