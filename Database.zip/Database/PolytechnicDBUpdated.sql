-- MySQL dump 10.13  Distrib 8.0.21, for osx10.13 (x86_64)
--
-- Host: localhost    Database: PolytechnicDB
-- ------------------------------------------------------
-- Server version	8.0.21

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `course`
--

DROP TABLE IF EXISTS `course`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `course` (
  `CourseID` varchar(5) NOT NULL,
  `CourseName` varchar(30) DEFAULT NULL,
  `LectID` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`CourseID`),
  KEY `fk_course` (`LectID`),
  CONSTRAINT `fk_course` FOREIGN KEY (`LectID`) REFERENCES `lecturer` (`LectID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course`
--

LOCK TABLES `course` WRITE;
/*!40000 ALTER TABLE `course` DISABLE KEYS */;
INSERT INTO `course` VALUES ('C1000','Software Development','L1001'),('C1001','Artificial Intelegence','L1003'),('C1002','Database Management','L1002'),('C1003','Interactive Multimedia','L1010'),('C1004','Networking','L1005');
/*!40000 ALTER TABLE `course` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `department`
--

DROP TABLE IF EXISTS `department`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `department` (
  `DepartID` varchar(30) NOT NULL,
  `DepartName` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`DepartID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `department`
--

LOCK TABLES `department` WRITE;
/*!40000 ALTER TABLE `department` DISABLE KEYS */;
INSERT INTO `department` VALUES ('D1000','Software Engineering'),('D1001','Industrial Computing'),('D1002','Comp System & Comm'),('D1003','Interactive Multimedia'),('D1004','Management');
/*!40000 ALTER TABLE `department` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lecturer`
--

DROP TABLE IF EXISTS `lecturer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lecturer` (
  `LectID` varchar(5) NOT NULL,
  `LectName` varchar(20) DEFAULT NULL,
  `LectTelNo` int DEFAULT NULL,
  `DepartID` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`LectID`),
  KEY `fk_lecturer` (`DepartID`),
  CONSTRAINT `fk_lecturer` FOREIGN KEY (`DepartID`) REFERENCES `department` (`DepartID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lecturer`
--

LOCK TABLES `lecturer` WRITE;
/*!40000 ALTER TABLE `lecturer` DISABLE KEYS */;
INSERT INTO `lecturer` VALUES ('L1001','Mokhsin',178908767,'D1000'),('L1002','Sheima',192299090,'D1000'),('L1003','Raju',101989909,'D1001'),('L1004','Zulkifli',123984902,'D1000'),('L1005','Rahmad',145667389,'D1002'),('L1006','Naina',143662738,'D1001'),('L1007','Junaida',13555728,NULL),('L1008','Hamid',123456789,'D1004'),('L1009','Chong',122236787,NULL),('L1010','Sam',144238787,'D1003');
/*!40000 ALTER TABLE `lecturer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stud_sub`
--

DROP TABLE IF EXISTS `stud_sub`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stud_sub` (
  `StudSubID` varchar(5) NOT NULL,
  `StudID` varchar(5) DEFAULT NULL,
  `SubID` varchar(5) DEFAULT NULL,
  `Mark` int DEFAULT NULL,
  `Grade` char(2) DEFAULT NULL,
  PRIMARY KEY (`StudSubID`),
  KEY `fk_stud_sub` (`StudID`),
  KEY `fk2_stud_sub` (`SubID`),
  CONSTRAINT `fk2_stud_sub` FOREIGN KEY (`SubID`) REFERENCES `subject` (`SubID`),
  CONSTRAINT `fk_stud_sub` FOREIGN KEY (`StudID`) REFERENCES `student` (`StudID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stud_sub`
--

LOCK TABLES `stud_sub` WRITE;
/*!40000 ALTER TABLE `stud_sub` DISABLE KEYS */;
INSERT INTO `stud_sub` VALUES ('SS100','IT101','SC100',60,'B'),('SS101','IT102','SC100',85,'A'),('SS102','IT103','SC100',90,'A'),('SS103','IT104','SC103',76,'B'),('SS104','IT105','SC103',56,'C'),('SS105','IT106','SC104',65,'B'),('SS106','IT101','SC104',45,'D'),('SS107','IT102','SC104',98,'A'),('SS108','IT103','SC101',67,'B'),('SS109','IT104','SC101',54,'C'),('SS110','IT105','SC101',87,'A'),('SS111','IT106','SC101',83,'A');
/*!40000 ALTER TABLE `stud_sub` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student`
--

DROP TABLE IF EXISTS `student`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `student` (
  `StudID` varchar(5) NOT NULL,
  `StudName` varchar(30) DEFAULT NULL,
  `StudAddress` varchar(30) DEFAULT NULL,
  `StudBirthDate` date DEFAULT NULL,
  `CourseID` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`StudID`),
  KEY `fk_student` (`CourseID`),
  CONSTRAINT `fk_student` FOREIGN KEY (`CourseID`) REFERENCES `course` (`CourseID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student`
--

LOCK TABLES `student` WRITE;
/*!40000 ALTER TABLE `student` DISABLE KEYS */;
INSERT INTO `student` VALUES ('IT101','Aminah','Perak','1990-10-19','C1000'),('IT102','Joe','Selangor','1990-08-13','C1000'),('IT103','Mona','Perak','1991-07-23','C1000'),('IT104','Husna','Melaka','1990-05-09','C1002'),('IT105','Lingling','Melaka','1989-07-07','C1004'),('IT106','Maniam','Penang','1989-12-01','C1003');
/*!40000 ALTER TABLE `student` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subject`
--

DROP TABLE IF EXISTS `subject`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subject` (
  `SubID` varchar(5) NOT NULL,
  `SubName` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`SubID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subject`
--

LOCK TABLES `subject` WRITE;
/*!40000 ALTER TABLE `subject` DISABLE KEYS */;
INSERT INTO `subject` VALUES ('SC100','Program Technique'),('SC101','System Development'),('SC102','Database'),('SC103','Object Oriented'),('SC104','Multimedia System');
/*!40000 ALTER TABLE `subject` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-11-15  4:40:02
