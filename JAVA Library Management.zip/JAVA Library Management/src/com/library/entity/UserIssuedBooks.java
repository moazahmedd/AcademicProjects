package com.library.entity;

public class UserIssuedBooks {
    private String studentId;

    public UserIssuedBooks() {
    }

    public UserIssuedBooks(String studentId) {
        this.studentId = studentId;
    }

    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    @Override
    public String toString() {
        return "UserIssuedBooks{" +
                "studentId='" + studentId + '\'' +
                '}';
    }
}

