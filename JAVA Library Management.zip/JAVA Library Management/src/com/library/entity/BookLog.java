package com.library.entity;

public class BookLog {
    private static String bookId;

    public BookLog() {
    }

    public BookLog(String bookId) {
        this.bookId = bookId;
    }

    public static String getBookId() {
        return bookId;
    }

    public void setBookId(String bookId) {
        this.bookId = bookId;
    }

    @Override
    public String toString() {
        return "BookIssued{" +
                "bookId='" + bookId + '\'' +
                '}';
    }
}
