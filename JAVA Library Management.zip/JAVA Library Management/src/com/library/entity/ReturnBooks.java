package com.library.entity;

public class ReturnBooks {
    private String issuedTill;
    private String IssueId;
    private String bookId;

    public ReturnBooks(String issuedTill, String issueId, String bookId) {
        this.issuedTill = issuedTill;
        IssueId = issueId;
        this.bookId = bookId;
    }


    public ReturnBooks() {

    }

    public String getBookId() {
        return bookId;
    }

    public void setBookId(String bookId) {
        this.bookId = bookId;
    }

    public String getIssuedTill() {
        return issuedTill;
    }

    public void setIssuedTill(String issuedTill) {
        this.issuedTill = issuedTill;
    }

    public String getIssueId() {
        return IssueId;
    }

    public void setIssueId(String issueId) {
        IssueId = issueId;
    }

    @Override
    public String toString() {
        return "ReturnBooks{" +
                "issuedTill='" + issuedTill + '\'' +
                ", IssueId='" + IssueId + '\'' +
                '}';
    }
}
