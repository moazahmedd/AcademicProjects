

package com.library.util;

public class DBSettings {
    public static final String ip="localhost";
    public static final String port="3306";
    public static final String db="library";
    public static final String userName="root";
    public static final String password="1234";


}
