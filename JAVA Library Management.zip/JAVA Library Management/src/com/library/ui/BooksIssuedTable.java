package com.library.ui;


import com.library.entity.BookLog;
import com.library.util.ConnectionDB;

import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class BooksIssuedTable {
    BookslLogUI thGui;

    private JPanel contentPane;
    private JTable table;

    public BooksIssuedTable(BookLog bookLog) throws Exception {

        BookslLogUI bookslLogUI = new BookslLogUI();

        String bookId = ( BookLog.getBookId() );
        Connection con = ConnectionDB.getConnectionDB();
        PreparedStatement ps = con.prepareStatement("select issuebooks.Student_id,issuebooks.Issue_id,issuebooks.Book_ID,issuebooks.issue_date,issuebooks.return_date,student.Student_name,student.Student_dept,student.Student_school from issuebooks INNER JOIN student ON issuebooks.Student_id = student.Student_id AND Book_ID = ?");
        ps.setString(1, bookId);
        ResultSet rs = ps.executeQuery();
        String[] finalArray = new String[8];
        String[] storageArray = new String[8];

        int rows = 0;
        int columns = 0;

        String data[][] = new String[10][8];

        while (rs.next()) {
            System.out.println(rs.getRow());
            String studentId1 = rs.getString("Student_id");
            String issueId = rs.getString("Issue_Id");
            String bId = rs.getString("Book_ID");
            String naam = rs.getString("Student_name");
            String stddpt = rs.getString("Student_dept");
            String school = rs.getString("Student_school");
            String issueDate = rs.getString("issue_date");
            String return_date = rs.getString("return_date");

            String newIssueId = String.valueOf(issueId);
            String newBookId = String.valueOf(bId);
            String newStudentId = String.valueOf(studentId1);

            data[rows][0] = newStudentId;
            data[rows][1] = newIssueId;
            data[rows][2] = newBookId;
            data[rows][3] = naam;
            data[rows][4] = stddpt;
            data[rows][5] = school;
            data[rows][6] = issueDate;
            data[rows][7] = return_date;

            rows++;
        }
        JFrame f;
        f = new JFrame();
        String column[] = {"Student ID", "Issue ID", "Book ID", "Student Name", "Student Dept.", "Student School", "Issue Date", "Return Date"};
        JTable jt = new JTable(data, column);
        jt.setBounds(30, 40, 1000, 600);
        JScrollPane sp = new JScrollPane(jt);
        f.add(sp);
        f.setSize(650, 400);
        f.setVisible(true);
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        f.setLocation(dim.width/2-f.getSize().width/2, dim.height/2-f.getSize().height/2);


    }

























}
