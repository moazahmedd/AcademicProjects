package com.library.ui;

import com.library.bl.ReturnBooksBusinessHandler;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;

public class ReturnBookUi extends JFrame {
    JLabel title;

    JLabel lblTotalPeriod;
    JLabel lblIssueId;
    JLabel lblBookid;

    JButton btnReturn;
    JButton btnCancel;

    JTextField txtTotalPeriod;
    JTextField txtIssueId;
    JTextField txtBookId;

    public ReturnBookUi() throws HeadlessException{
        init();
    }

    public JLabel getLblBookid() {
        return lblBookid;
    }

    public void setLblBookid(JLabel lblBookid) {
        this.lblBookid = lblBookid;
    }

    public JTextField getTxtBookId() {
        return txtBookId;
    }

    public void setTxtBookId(JTextField txtBookId) {
        this.txtBookId = txtBookId;
    }

    public void init(){
        Font font1 = new Font("cursive", Font.BOLD, 12);
        Font font2 = new Font("Arial", Font.ITALIC, 14);
        Font font3 = new Font("Arial", Font.BOLD, 22);

        title = new JLabel();
        title.setText("Return A Book");
        title.setBounds(180,20,300,40);
        title.setFont(new Font("Times New Roman", Font.ITALIC+Font.BOLD, 22));

        lblBookid=  new JLabel();
        lblBookid.setText("Book ID : ");
        lblBookid.setBounds(30,90,120,30);

        txtBookId = new JTextField();
        txtBookId.setBounds(180,90,250,30);

        lblIssueId = new JLabel();
        lblIssueId.setText("Issue ID : ");
        lblIssueId.setBounds(30,150,120,30);

        txtIssueId = new JTextField();
        txtIssueId.setBounds(180,150,250,30);

        lblTotalPeriod = new JLabel();
        lblTotalPeriod.setText("Return Date : ");
        lblTotalPeriod.setBounds(30,210,120,30);

        txtTotalPeriod = new JTextField();
        txtTotalPeriod.setBounds(180,210,250,30);

        btnReturn = new JButton();
        btnReturn.setText("Return");
        btnReturn.setBounds(150,270,100,40);
        btnReturn.setBackground(Color.darkGray);
        btnReturn.setForeground(Color.white);
        btnReturn.setOpaque(true);
        btnReturn.setBorderPainted(false);

        btnCancel = new JButton();
        btnCancel.setText("Cancel");
        btnCancel.setBounds(270,270,100,40);
        btnCancel.setBackground(Color.gray);
        btnCancel.setForeground(Color.white);
        btnCancel.setOpaque(true);
        btnCancel.setBorderPainted(false);

        this.getContentPane().setLayout(null);
        this.getContentPane().add(lblIssueId);
        this.getContentPane().add(txtIssueId);
        this.getContentPane().add(lblTotalPeriod);
        this.getContentPane().add(txtTotalPeriod);
        this.getContentPane().add(title);
        this.getContentPane().add(btnReturn);
        this.getContentPane().add(btnCancel);
        this.getContentPane().add(lblBookid);
        this.getContentPane().add(txtBookId);

        ReturnBooksBusinessHandler returnBooksBusinessHandler= new ReturnBooksBusinessHandler(this);
        btnReturn.addActionListener(returnBooksBusinessHandler);
        btnCancel.addActionListener(returnBooksBusinessHandler);

        JFrame.setDefaultLookAndFeelDecorated(true);
        this.setSize(500,390);
        this.show();
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        this.setLocation(dim.width/2-this.getSize().width/2, dim.height/2-this.getSize().height/2);

    }

    public  static void main(String[] args){
        ReturnBookUi returnBookUi = new ReturnBookUi();

    }


    public void setTitle(JLabel title) {
        this.title = title;
    }

    public JLabel getLblTotalPeriod() {
        return lblTotalPeriod;
    }

    public void setLblTotalPeriod(JLabel lblTotalPeriod) {
        this.lblTotalPeriod = lblTotalPeriod;
    }

    public JLabel getLblIssueId() {
        return lblIssueId;
    }

    public void setLblIssueId(JLabel lblIssueId) {
        this.lblIssueId = lblIssueId;
    }

    public JButton getBtnReturn() {
        return btnReturn;
    }

    public void setBtnReturn(JButton btnReturn) {
        this.btnReturn = btnReturn;
    }

    public JButton getBtnCancel() {
        return btnCancel;
    }

    public void setBtnCancel(JButton btnCancel) {
        this.btnCancel = btnCancel;
    }

    public JTextField getTxtTotalPeriod() {
        return txtTotalPeriod;
    }

    public void setTxtTotalPeriod(JTextField txtTotalPeriod) {
        this.txtTotalPeriod = txtTotalPeriod;
    }

    public JTextField getTxtIssueId() {
        return txtIssueId;
    }

    public void setTxtIssueId(JTextField txtIssueId) {
        this.txtIssueId = txtIssueId;
    }
}
